import binascii     # na vypocet checksum-u
import math         # na zaokruhlovanie
import ntpath       # na oddelenie basename-u absolutnej cesty
import os           # na pracu s cestami suborov
import socket       # na komunikaciu
import struct       # na tvorbu hlaviciek
import random       # na vyber chybneho packetu pri simulacii chyby
import time         # na casovanie threadov
import threading    # na spustenie KPA na inom jadre ako bezi program

keepAlive = False


def userIsSender():
    global keepAlive
    senderSocket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    dstAddress = input("\nEnter the destination IP address: ")
    dstPort = int(input("Enter the destination port: "))

    destination = (dstAddress, dstPort)

    while True:

        print("\nEnter 1. for sending a text message.")
        print("Enter 2. for sending a file. ")
        print("Enter anything else to return to function selection or break connection if active.")
        typeOfData = input("Your input: ")

        match typeOfData:
            case "1":   # message case

                if keepAlive is True:
                    keepAlive = False
                    sendNEW = struct.pack("c", str.encode("7").strip())
                    senderSocket.sendto(sendNEW, destination)

                msg = input("\nEnter the message you wish to send: ")

                fragmentSize = int(input("\nEnter the size of a fragment (max 1493B): "))
                while fragmentSize > 1493 or fragmentSize < 0:
                    fragmentSize = int(input("\nIncorrect input. Please try again: "))

                try:

                    error = input("Do you want to generate an error? (y/n) ")
                    numOfPackets = math.ceil(len(msg) / fragmentSize)

                    print("\nSize of message: " + str(len(msg)) + ", number of packets: " + str(numOfPackets))
                    metaPacket = struct.pack("c", str.encode("0").strip()) + struct.pack("HHH", numOfPackets, fragmentSize, len(msg))

                    if error == "y":
                        if numOfPackets == 1:
                            errorIndex = 1
                        else:
                            errorIndex = random.randint(1, numOfPackets-1)
                            print("Error index: " + str(errorIndex))
                    else:
                        errorIndex = 0

                    senderSocket.sendto(metaPacket.strip(), destination)    # init paket s info

                    data, addr = senderSocket.recvfrom(1500)

                    socket.timeout(20)

                    if data[:1].decode() == "3":
                        print("Received ACK, sending data...")

                        i = 0

                        while i != numOfPackets:    # posielanie paketov
                            fragment = msg[:fragmentSize]
                            msg = msg[fragmentSize:]
                            dataPacket = struct.pack("c", str.encode("1").strip()) + struct.pack("HH", i, fragmentSize)
                            crc = binascii.crc_hqx(dataPacket + fragment.encode(), 0)
                            if i == errorIndex-1:    # ak je dany paket paket ktory ma simulovat chybu
                                crcError = crc % random.randint(2, 10)
                                dataPacketFinal = struct.pack("c", str.encode("1").strip()) + struct.pack("HHH", i, fragmentSize, crcError)
                                senderSocket.sendto(dataPacketFinal + fragment.encode(), destination)
                            else:
                                dataPacketFinal = struct.pack("c", str.encode("1").strip()) + struct.pack("HHH", i, fragmentSize, crc)
                                senderSocket.sendto(dataPacketFinal + fragment.encode(), destination)
                            dataPacketFinal = struct.pack("c", str.encode("1").strip()) + struct.pack("HHH", i, fragmentSize, crc)
                            packData, addr = senderSocket.recvfrom(1500)

                            if packData[:1].decode() == "3":    # paket prisiel v poriadku
                                print("Packet " + str(i+1) + " sent successfully.")

                            elif packData[:1].decode() == "4":    # paket neprisiel v poriadku, resend
                                print("Packet " + str(i+1) + " has not been deliver successfuly.")
                                while True:
                                    senderSocket.sendto(dataPacketFinal + fragment.encode(), destination)

                                    ACKFlag, address = senderSocket.recvfrom(1500)
                                    if ACKFlag.decode() == "3":
                                        print("Resend of packet " + str(i + 1) + " successful.")
                                        break

                            i = i + 1
                        sendFIN = struct.pack("c", str.encode("2").strip())     #zaslanie FIN na potvrdenie konca posielania dat
                        senderSocket.sendto(sendFIN, addr)
                        FINACK, address = senderSocket.recvfrom(1500)

                        keepAlive = True
                        keepAliveThreadS = threading.Thread(target=keepAliveSender, args=(senderSocket, address))
                        keepAliveThreadS.daemon = True
                        keepAliveThreadS.start()

                    if data[:1].decode() == "4":
                        print("Received NAK - connection not established...")

                except socket.gaierror:
                    print("Could not find file!")
                    return
                except socket.timeout:
                    print("Could not establish connection!")
                    return

            case "2":       # file case
                if keepAlive is True:
                    keepAlive = False
                    sendNEW = struct.pack("c", str.encode("7").strip())
                    senderSocket.sendto(sendNEW, destination)

                nameOfFile = input("\nEnter the absolute path of the file you wish to send: ")
                sizeOfFile = os.path.getsize(nameOfFile)
                print("\nFound file " + nameOfFile + " with the size " + str(sizeOfFile) + " B.")
                print("Absolute path of file: " + os.path.abspath(nameOfFile))

                fragmentSize = int(input("\nEnter the size of a fragment (max 1493B): "))
                while fragmentSize > 1493 or fragmentSize < 0:
                    fragmentSize = int(input("\nIncorrect input. Please try again: "))

                generateError = input("Generate an error? (y/n): ")

                sendFile(nameOfFile, sizeOfFile, fragmentSize, generateError, senderSocket, destination)

            case _:   # navrat do mainu
                if keepAlive is True:   # ak je keepAlive aktivna rusime ju a dame o tom info aj prijmatelovi
                    keepAlive = False

                    sendCHG = struct.pack("c", str.encode("6").strip())
                    senderSocket.sendto(sendCHG, destination)

                return


def sendFile(nameOfFile, sizeOfFile, fragmentSize, generateError, senderSocket, destination):
    global keepAlive
    numOfPackets = math.ceil(sizeOfFile / fragmentSize)

    if generateError == "y":
        if numOfPackets == 1:
            errorIndex = 1
        else:
            errorIndex = random.randint(1, numOfPackets - 1)
            print("Error index: " + str(errorIndex))
    else:
        errorIndex = 0

    with open(nameOfFile, mode="rb") as file:
        contentOfFile = file.read()

    if len(contentOfFile) == 0:
        print("The file is empty!")
        return

    print("\nSize of file: " + str(sizeOfFile) + ", number of packets: " + str(numOfPackets))
    metaPacket = struct.pack("c", str.encode("8").strip()) + struct.pack("HH", numOfPackets, fragmentSize)
    senderSocket.sendto(metaPacket.strip() + nameOfFile.encode(), destination)  # init paket s info

    print("Waiting for receiver to set file save destination...")
    data, addr = senderSocket.recvfrom(1500)

    if data[:1].decode() == "3":
        print("Received ACK, sending data...")

        i = 0

        while i != numOfPackets:
            fragment = contentOfFile[:fragmentSize]
            contentOfFile = contentOfFile[fragmentSize:]

            dataPacket = struct.pack("c", str.encode("1").strip()) + struct.pack("HH", i, fragmentSize)
            crc = binascii.crc_hqx(dataPacket + fragment, 0)

            if i == errorIndex - 1:
                crcError = crc % random.randint(2, 10)
                dataPacketFinal = struct.pack("c", str.encode("1").strip()) + struct.pack("HHH", i, fragmentSize, crcError)
                senderSocket.sendto(dataPacketFinal + fragment, destination)
            else:
                dataPacketFinal = struct.pack("c", str.encode("1").strip()) + struct.pack("HHH", i, fragmentSize, crc)
                senderSocket.sendto(dataPacketFinal + fragment, destination)

            dataPacketFinal = struct.pack("c", str.encode("1").strip()) + struct.pack("HHH", i, fragmentSize, crc)
            packData, addr = senderSocket.recvfrom(1500)

            if packData[:1].decode() == "3":  # paket prisiel v poriadku
                print("Packet " + str(i + 1) + " sent successfully.")

            elif packData[:1].decode() == "4":  # paket neprisiel v poriadku, resend
                print("Packet " + str(i + 1) + " has not been deliver successfuly.")
                while True:
                    senderSocket.sendto(dataPacketFinal + fragment, destination)

                    ACKFlag, address = senderSocket.recvfrom(1500)
                    if ACKFlag.decode() == "3":
                        print(errorIndex)
                        print("Resend of packet " + str(i + 1) + " successful.")
                        break

            i = i + 1

        sendFIN = struct.pack("c", str.encode("2").strip())
        senderSocket.sendto(sendFIN, addr)
        FINACK, address = senderSocket.recvfrom(1500)
        print("END")

        keepAlive = True
        keepAliveThreadS = threading.Thread(target=keepAliveSender, args=(senderSocket, address))
        keepAliveThreadS.daemon = True
        keepAliveThreadS.start()

    if data[:1].decode() == "4":
        print("Received NAK - connection not established...")


def userIsReceiver():
    global keepAlive
    receiverSocket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    port = int(input("\nEnter the receiving port: "))

    receiverSocket.bind(("", port))

    while True:
        print("\nReady to receive.")

        data, addr = receiverSocket.recvfrom(1500)
        typeComm = data[:1].decode()

        if typeComm == "0":
            numOfPackets, fragmentSize, sizeOfMsg = struct.unpack("HHH", data[1:7])

            sendACK = struct.pack("c", str.encode("3").strip())
            receiverSocket.sendto(sendACK, addr)
            print("Connection established, receiving  " + str(numOfPackets) + " in fragments of " + str(fragmentSize) + "B.")
            i = 0
            textMessage = ""

            while i != numOfPackets+1:

                data, address = receiverSocket.recvfrom(1500)

                if data[:1].decode() == "1":            # prisiel data paket
                    print("Receiving packet " + str(i+1) + ".")

                    packetNumber, fragmentSize, crc = struct.unpack("HHH", data[1:7])
                    crcCheckPacket = struct.pack("c", str.encode("1").strip()) + struct.pack("HH", packetNumber, fragmentSize)
                    crcCheck = binascii.crc_hqx(crcCheckPacket + data[7:], 0)

                    if crcCheck == crc:
                        sendACK = struct.pack("c", str.encode("3").strip())
                        receiverSocket.sendto(sendACK, address)
                        textMessage += data[7:].decode()
                        i += 1
                    else:
                        sendNACK = struct.pack("c", str.encode("4").strip())
                        receiverSocket.sendto(sendNACK, address)
                        print("NAK - Requesting resend.")

                if data[:1].decode() == "2":
                    print("\nText message of size " + str(sizeOfMsg) + " received successfully!")
                    sendACK = struct.pack("c", str.encode("3").strip())
                    receiverSocket.sendto(sendACK, address)
                    print("Message: " + str(textMessage))

                    keepAlive = True
                    endConn = keepAliveReceiver(receiverSocket)

                    if endConn is True:
                        return

                    i += 1

        if typeComm == "8":
            saveFilePath = input("Enter the path of where you want to save your file (ex: C:\\Users\\User\\Desktop): ")

            numOfPackets, fragmentSize = struct.unpack("HH", data[1:5])
            fileName = data[5:].decode()
            sendACK = struct.pack("c", str.encode("3").strip())
            receiverSocket.sendto(sendACK, addr)
            print("Connection established, receiving " + str(numOfPackets) + " packets in fragments of " + str(fragmentSize) + "B.")

            i = 0

            contentOfFile = b''

            while i != numOfPackets+1:

                data, address = receiverSocket.recvfrom(1500)

                if data[:1].decode() == "1":            # prisiel data paket

                    packetNumber, fragmentSize, crc = struct.unpack("HHH", data[1:7])
                    crcCheckPacket = struct.pack("c", str.encode("1").strip()) + struct.pack("HH", packetNumber, fragmentSize)
                    crcCheck = binascii.crc_hqx(crcCheckPacket + data[7:], 0)

                    if crcCheck == crc:
                        sendACK = struct.pack("c", str.encode("3").strip())
                        receiverSocket.sendto(sendACK, address)
                        contentOfFile += data[7:]
                        print("Receiving packet " + str(i + 1) + "-> ACK")
                        i += 1

                    else:
                        sendNACK = struct.pack("c", str.encode("4").strip())
                        receiverSocket.sendto(sendNACK, address)
                        print("Receiving packet " + str(i + 1) + "-> NAK - Requesting resend.")

                if data[:1].decode() == "2":        # prisiel FIN
                    print("\nFile received successfully!")
                    sendACK = struct.pack("c", str.encode("3").strip())
                    receiverSocket.sendto(sendACK, address)

                    sizeOfSavedFile = os.path.getsize(fileName)

                    fileName = ntpath.basename(fileName)

                    dstPath = saveFilePath + "\\" + fileName

                    receivedFile = open(dstPath, "wb")

                    receivedFile.write(contentOfFile)
                    receivedFile.close()

                    print("The file \"" + fileName + "\" has been received with the size of " + str(sizeOfSavedFile) + "B")
                    print("Absolute path: " + dstPath)

                    keepAlive = True
                    endConn = keepAliveReceiver(receiverSocket)

                    if endConn is True:
                        return

                    i += 1


def keepAliveSender(senderSocket, address):     # odosielatelovi bezi keep Alive na vlákne
    while True:
        try:
            socket.timeout(30)

            time.sleep(5)
            if keepAlive is False:
                return

            sendKPA = struct.pack("c", str.encode("5").strip())
            senderSocket.sendto(sendKPA, address)

            print("Sent KPA")

            receiveKPA, address = senderSocket.recvfrom(1500)

            if receiveKPA.decode() == "5":
                print("KPA received")

        except socket.gaierror:
            print("Socket Error!")
            return

        except socket.timeout:
            print("Keep-alive not received, time ran out.")
            return


def keepAliveReceiver(receiverSocket):  # prijmatel vojde do funkcie a udrzuje konekcie kym nepride poziadavka na nieco ine
    global keepAlive
    while True:
        if keepAlive is False:
            return False

        receiveKPA, address = receiverSocket.recvfrom(1500)
        if receiveKPA.decode() == "5":
            print("KPA received")

        if receiveKPA.decode() == "6":
            print("Connection canceled by sender.")
            keepAlive = False
            return True

        if receiveKPA.decode() == "7":
            keepAlive = False
            return False

        time.sleep(5)

        sendKPA = struct.pack("c", str.encode("5").strip())
        receiverSocket.sendto(sendKPA, address)
        print("Sent KPA")


def main():

    while True:
        print("\nEnter 1. for sender.")
        print("Enter 2. for receiver.")
        print("Enter anything else to exit.")
        userInput = input("Enter your choice: ")

        match userInput:
            case "1":
                userIsSender()
            case "2":
                userIsReceiver()
            case _:
                print("Exiting program...")
                return 0


main()

