from pydantic import BaseModel, EmailStr
from typing import List
from datetime import date, datetime

from uuid import UUID, uuid4

from pydantic.class_validators import Optional


class UpdateUser(BaseModel):
    name: Optional[str] = None
    surname: Optional[str] = None
    email: Optional[EmailStr] = None
    birth_date: Optional[date] = None
    personal_identificator: Optional[str] = None

    class Config:
        orm_mode = True


class Reservation(BaseModel):
    id: UUID
    user_id: UUID
    publication_id: UUID
    created_at: datetime

    class Config:
        orm_mode = True


class Rental(BaseModel):
    id: UUID
    user_id: UUID
    publication_instance_id: UUID
    duration: int
    start_date: datetime
    end_date: datetime
    status: str

    class Config:
        orm_mode = True


class UserWithReservationsAndRentals(BaseModel):
    id: UUID
    name: str
    surname: str
    email: EmailStr
    birth_date: date
    personal_identificator: str
    reservations: Optional[List[Reservation]]
    rentals: Optional[List[Rental]]
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True


class UserWithoutReservationsAndRentals(BaseModel):
    id: UUID
    name: str
    surname: str
    email: EmailStr
    birth_date: date
    personal_identificator: str
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True


class CreateUser(BaseModel):
    id: UUID
    name: str
    surname: str
    email: EmailStr
    birth_date: date
    personal_identificator: str

    class Config:
        orm_mode = True


class ReservationCreate(BaseModel):
    id: Optional[UUID]
    user_id: UUID
    publication_id: UUID

    class Config:
        orm_mode = True


class ReservationCreateOut(BaseModel):
    id: UUID
    user_id: UUID
    publication_id: UUID
    created_at: datetime

    class Config:
        orm_mode = True


class CardsCreate(BaseModel):
    id: Optional[UUID]
    user_id: UUID
    magstripe: str
    status: str

    class Config:
        orm_mode = True


class CardsCreateOut(BaseModel):
    id: UUID
    user_id: UUID
    magstripe: str
    status: str
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True


class CardUpdate(BaseModel):
    status: str
    user_id: UUID

    class Config:
        orm_mode = True


class RentalCreate(BaseModel):
    id: Optional[UUID]
    user_id: UUID
    publication_id: UUID
    duration: int

    class Config:
        orm_mode = True


class RentalCreateOut(BaseModel):
    id: Optional[UUID]
    user_id: UUID
    publication_instance_id: UUID
    duration: int
    start_date: datetime
    end_date: datetime
    status: str

    class Config:
        orm_mode = True


class RentalUpdate(BaseModel):
    duration: Optional[int]

    class Config:
        orm_mode = True


class Author(BaseModel):
    name: str
    surname: str

    class Config:
        orm_mode = True


class PublicationCreate(BaseModel):
    id: Optional[UUID]
    title: str
    authors: List[Author]
    categories: List[str]

    class Config:
        orm_mode = True


class PublicationCreateOut(BaseModel):
    id: UUID
    title: str
    authors: List[Author]
    categories: List[str]
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True


class PublicationInstanceCreate(BaseModel):
    id: UUID
    type: str
    publisher: str
    year: int
    status: Optional[str] = "available"
    publication_id: UUID

    class Config:
        orm_mode = True


class PublicationInstanceCreateOut(BaseModel):
    id: Optional[UUID]
    type: str
    publisher: str
    year: int
    status: str
    publication_id: UUID
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True


class PublicationInstanceUpdate(BaseModel):
    type: Optional[str]
    publisher: Optional[str]
    year: Optional[int]
    status: Optional[str]

    class Config:
        orm_mode = True


class CreateAuthor(BaseModel):
    id: Optional[UUID]
    name: str
    surname: str

    class Config:
        orm_mode = True


class CreateAuthorOut(BaseModel):
    id: UUID
    name: str
    surname: str
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True


class GetAuthor(BaseModel):
    id: UUID
    name: str
    surname: str
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True


class UpdateAuthor(BaseModel):
    name: Optional[str] = None
    surname: Optional[str] = None


class CreateCategory(BaseModel):
    id: Optional[UUID]
    name: str

    class Config:
        orm_mode = True


class CreateCategoryOut(BaseModel):
    id: Optional[UUID]
    name: str
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True

