from uuid import uuid4
from sqlalchemy import Column, BIGINT, VARCHAR, DATE, DATETIME, FLOAT, ForeignKey, Boolean, UUID, func, TIMESTAMP
from sqlalchemy.orm import relationship
from db_setup import Base


class Users(Base):
    __tablename__ = "users"
    id = Column(UUID, primary_key=True)
    name = Column(VARCHAR(40))
    surname = Column(VARCHAR(40))
    email = Column(VARCHAR(40))
    magstripe = Column(VARCHAR(40))
    birth_date = Column(DATE)
    personal_identificator = Column(VARCHAR(40))
    account_type = Column(VARCHAR(40))
    created_at = Column(TIMESTAMP, default=func.now())
    updated_at = Column(TIMESTAMP, default=func.now(), onupdate=func.now())

    card = relationship("Cards", back_populates="user")
    readingList = relationship("ReadingLists", back_populates="user")
    borrowing = relationship("Borrowings", back_populates="user")
    reservation = relationship("Reservations", back_populates="user")


class Cards(Base):
    __tablename__ = "cards"
    id = Column(UUID, primary_key=True)
    user_id = Column(UUID, ForeignKey('users.id'))
    magstripe = Column(VARCHAR(40))
    status = Column(VARCHAR(40))
    created_at = Column(TIMESTAMP, default=func.now())
    updated_at = Column(TIMESTAMP, default=func.now(), onupdate=func.now())

    user = relationship("Users", back_populates="card")


class Publications(Base):
    __tablename__ = "publications"
    publication_id = Column(UUID, primary_key=True)
    ISBN = Column(VARCHAR(40))
    title = Column(VARCHAR(40))
    publisher = Column(VARCHAR(40))
    publishing_date = Column(DATE)
    type = Column(VARCHAR(40))
    special_title = Column(VARCHAR(40))
    account_type = Column(VARCHAR(40))
    created_at = Column(TIMESTAMP, default=func.now())
    updated_at = Column(TIMESTAMP, default=func.now(), onupdate=func.now())

    instance = relationship("PublicationInstances", back_populates="publication")
    publicationAuthor = relationship("PublicationAuthors", back_populates="publication")
    publicationTitle = relationship("PublicationSpecialTitles", back_populates="publication")
    publicationGenre = relationship("PublicationCategories", back_populates="publication")
    review = relationship("Reviews", back_populates="publication")
    reservation = relationship("Reservations", back_populates="publication")
    item = relationship("PersonalReadingList", back_populates="publication")


class PublicationInstances(Base):
    __tablename__ = "publication_instances"
    id = Column(UUID, primary_key=True)
    publication_id = Column(UUID, ForeignKey('publications.publication_id'))
    type = Column(VARCHAR(40))
    publisher = Column(VARCHAR(40))
    year = Column(BIGINT)
    status = Column(VARCHAR(40))
    created_at = Column(TIMESTAMP, default=func.now())
    updated_at = Column(TIMESTAMP, default=func.now(), onupdate=func.now())

    borrowing = relationship("Borrowings", back_populates="instance")
    publication = relationship("Publications", back_populates="instance")


class Authors(Base):
    __tablename__ = "authors"
    id = Column(UUID, primary_key=True)
    name = Column(VARCHAR(40))
    surname = Column(VARCHAR(40))
    created_at = Column(TIMESTAMP, default=func.now())
    updated_at = Column(TIMESTAMP, default=func.now(), onupdate=func.now())

    publicationAuthor = relationship("PublicationAuthors", back_populates="author")


class PublicationAuthors(Base):
    __tablename__ = "publication_authors"
    publication_id = Column(UUID, ForeignKey('publications.publication_id'), primary_key=True)
    author_id = Column(UUID, ForeignKey('authors.id'), primary_key=True)
    created_at = Column(TIMESTAMP, default=func.now())
    updated_at = Column(TIMESTAMP, default=func.now(), onupdate=func.now())

    publication = relationship("Publications", back_populates="publicationAuthor")
    author = relationship("Authors", back_populates="publicationAuthor")


class SpecialTitles(Base):
    __tablename__ = "special_titles"
    special_title_id = Column(UUID, primary_key=True)
    special_title_name = Column(VARCHAR(40))
    created_at = Column(TIMESTAMP, default=func.now())
    updated_at = Column(TIMESTAMP, default=func.now(), onupdate=func.now())

    publicationTitle = relationship("PublicationSpecialTitles", back_populates="title")


class PublicationSpecialTitles(Base):
    __tablename__ = "publications_special_titles"
    publication_titles_id = Column(UUID, primary_key=True, default=uuid4())
    publication_id = Column(UUID, ForeignKey('publications.publication_id'))
    special_title_id = Column(UUID, ForeignKey('special_titles.special_title_id'))
    created_at = Column(TIMESTAMP, default=func.now())
    updated_at = Column(TIMESTAMP, default=func.now(), onupdate=func.now())

    publication = relationship("Publications", back_populates="publicationTitle")
    title = relationship("SpecialTitles", back_populates="publicationTitle")


class Categories(Base):
    __tablename__ = "categories"
    id = Column(UUID, primary_key=True)
    name = Column(VARCHAR(40))
    created_at = Column(TIMESTAMP, default=func.now())
    updated_at = Column(TIMESTAMP, default=func.now(), onupdate=func.now())

    publicationGenre = relationship("PublicationCategories", back_populates="category")


class PublicationCategories(Base):
    __tablename__ = "publication_categories"
    publication_id = Column(UUID, ForeignKey('publications.publication_id'), primary_key=True)
    category_id = Column(UUID, ForeignKey('categories.id'), primary_key=True)
    created_at = Column(TIMESTAMP, default=func.now())
    updated_at = Column(TIMESTAMP, default=func.now(), onupdate=func.now())

    publication = relationship("Publications", back_populates="publicationGenre")
    category = relationship("Categories", back_populates="publicationGenre")


class Reviews(Base):
    __tablename__ = "reviews"
    review_id = Column(UUID, primary_key=True)
    publication_id = Column(UUID, ForeignKey('publications.publication_id'))
    rating = Column(FLOAT)
    review_text = Column(VARCHAR(120))
    created_at = Column(TIMESTAMP, default=func.now())
    updated_at = Column(TIMESTAMP, default=func.now(), onupdate=func.now())

    publication = relationship("Publications", back_populates="review")


class Borrowings(Base):
    __tablename__ = "borrowings"
    borrowing_id = Column(UUID, primary_key=True)
    user_id = Column(UUID, ForeignKey('users.id'))
    instance_id = Column(UUID, ForeignKey('publication_instances.id'))
    duration = Column(BIGINT)
    status = Column(VARCHAR(40), default="active")
    start_date = Column(TIMESTAMP)
    end_date = Column(TIMESTAMP)
    created_at = Column(TIMESTAMP, default=func.now())
    updated_at = Column(TIMESTAMP, default=func.now(), onupdate=func.now())

    borrowingProlongation = relationship("BorrowingProlongations", back_populates="borrowing")
    penalty = relationship("Penalties", back_populates="borrowing")
    user = relationship("Users", back_populates="borrowing")
    instance = relationship("PublicationInstances", back_populates="borrowing")


class BorrowingProlongations(Base):
    __tablename__ = "borrowing_prolongations"
    prolongation_id = Column(UUID, primary_key=True)
    borrowing_id = Column(UUID, ForeignKey("borrowings.borrowing_id"))
    prolongation_date = Column(DATE)
    prolongation_end_date = Column(DATE)
    prolongation_number = Column(BIGINT)
    created_at = Column(TIMESTAMP, default=func.now())
    updated_at = Column(TIMESTAMP, default=func.now(), onupdate=func.now())

    borrowing = relationship("Borrowings", back_populates="borrowingProlongation")


class Penalties(Base):
    __tablename__ = "penalties"
    penalty_id = Column(UUID, primary_key=True)
    borrowing_id = Column(UUID, ForeignKey("borrowings.borrowing_id"))
    penalty_reason = Column(VARCHAR(40))
    penalty_amount = Column(FLOAT)
    penalty_date = Column(TIMESTAMP)
    penalty_payed = Column(Boolean)
    created_at = Column(TIMESTAMP, default=func.now())
    updated_at = Column(TIMESTAMP, default=func.now(), onupdate=func.now())

    borrowing = relationship("Borrowings", back_populates="penalty")
    notification = relationship("PenaltiesNotifications", back_populates="penalty")


class PenaltiesNotifications(Base):
    __tablename__ = "penalties_notifications"
    notification_id = Column(UUID, primary_key=True)
    penalty_id = Column(UUID, ForeignKey("penalties.penalty_id"))
    notification_type = Column(VARCHAR(40))
    date_of_notification = Column(TIMESTAMP)
    created_at = Column(TIMESTAMP, default=func.now())
    updated_at = Column(TIMESTAMP, default=func.now(), onupdate=func.now())

    penalty = relationship("Penalties", back_populates="notification")


class ReadingLists(Base):
    __tablename__ = "reading_lists"
    readingList_id = Column(UUID, primary_key=True)
    user_id = Column(UUID, ForeignKey("users.id"))

    item = relationship("PersonalReadingList", back_populates="readingList")
    user = relationship("Users", back_populates="readingList")


class PersonalReadingList(Base):
    __tablename__ = "personal_reading_list"
    item_id = Column(UUID, primary_key=True)
    readingList_id = Column(UUID, ForeignKey("reading_lists.readingList_id"))
    publication_id = Column(UUID, ForeignKey('publications.publication_id'))
    already_read = Column(Boolean)
    created_at = Column(TIMESTAMP, default=func.now())
    updated_at = Column(TIMESTAMP, default=func.now(), onupdate=func.now())

    readingList = relationship("ReadingLists", back_populates="item")
    publication = relationship("Publications", back_populates="item")


class Reservations(Base):
    __tablename__ = "reservations"
    reservation_id = Column(UUID, primary_key=True)
    user_id = Column(UUID, ForeignKey("users.id"))
    publication_id = Column(UUID, ForeignKey('publications.publication_id'))
    created_at = Column(TIMESTAMP, default=func.now())
    updated_at = Column(TIMESTAMP, default=func.now(), onupdate=func.now())

    user = relationship("Users", back_populates="reservation")
    publication = relationship("Publications", back_populates="reservation")
