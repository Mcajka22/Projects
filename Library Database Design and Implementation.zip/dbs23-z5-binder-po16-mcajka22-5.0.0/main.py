
from typing import Union
from uuid import uuid4

from fastapi import FastAPI, Depends, HTTPException
from fastapi.exceptions import RequestValidationError
from pydantic.datetime_parse import timedelta
from sqlalchemy import func
from sqlalchemy.orm import Session, joinedload
from starlette.middleware.cors import CORSMiddleware
from uuid import UUID

from starlette.requests import Request
from starlette.responses import JSONResponse

from db_setup import engine, SessionLocal
import models
import schemas

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Creates library DB tables
models.Base.metadata.create_all(bind=engine)


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


@app.exception_handler(RequestValidationError)
async def validation_exception_handler(request: Request, exc: RequestValidationError):
    return JSONResponse(
        status_code=400,
        content={"detail": exc.errors(), "body": exc.body},
    )


@app.post("/users", response_model=Union[schemas.UserWithoutReservationsAndRentals, schemas.UserWithReservationsAndRentals], status_code=201)
async def create_user(user_data: schemas.CreateUser, db: Session = Depends(get_db)):
    try:

        existing_user = db.query(models.Users).filter(models.Users.email == user_data.email).first()
        if existing_user:
            raise HTTPException(status_code=409, detail="Email is already taken")

        new_user = models.Users(
            id=user_data.id,
            name=user_data.name,
            surname=user_data.surname,
            email=user_data.email,
            birth_date=user_data.birth_date,
            personal_identificator=user_data.personal_identificator,
        )

        db.add(new_user)

        try:
            db.commit()
        except Exception as e:
            db.rollback()
            raise HTTPException(status_code=400, detail="Bad Request")

        user = db.query(models.Users)\
            .options(joinedload(models.Users.reservation))\
            .options(joinedload(models.Users.borrowing))\
            .filter(models.Users.id == new_user.id)\
            .first()

        created_user = schemas.UserWithReservationsAndRentals.from_orm(user)

        if not created_user.reservations and not created_user.rentals:
            response_user = schemas.UserWithoutReservationsAndRentals.from_orm(created_user)
            return response_user
        else:
            return created_user

    except Exception as error:
        raise error


@app.get("/users/{user_id}", response_model=Union[schemas.UserWithoutReservationsAndRentals, schemas.UserWithReservationsAndRentals])
async def get_user(user_id: UUID, db: Session = Depends(get_db)):
    user = db.query(models.Users)\
        .options(joinedload(models.Users.reservation))\
        .options(joinedload(models.Users.borrowing))\
        .filter(models.Users.id == user_id)\
        .first()

    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    existing_user = schemas.UserWithReservationsAndRentals.from_orm(user)

    if not existing_user.reservations and not existing_user.rentals:
        response_user = schemas.UserWithoutReservationsAndRentals.from_orm(existing_user)
        return response_user
    else:
        return existing_user


@app.patch("/users/{user_id}", response_model=schemas.UserWithReservationsAndRentals)
async def update_user(user_id: UUID, user_data: schemas.UpdateUser, db: Session = Depends(get_db)):
    user = db.query(models.Users).filter(models.Users.id == user_id).first()

    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    if user_data.email:
        existing_user = db.query(models.Users).filter(models.Users.email == user_data.email).first()
        if existing_user and existing_user.id != user_id:
            raise HTTPException(status_code=409, detail="Email is already taken")

    for field, value in user_data:
        if value is not None:
            setattr(user, field, value)

    try:
        db.commit()
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=400, detail="Bad Request")

    updated_user = db.query(models.Users)\
        .options(joinedload(models.Users.reservation))\
        .options(joinedload(models.Users.borrowing))\
        .filter(models.Users.id == user_id)\
        .first()

    return schemas.UserWithReservationsAndRentals.from_orm(updated_user)


@app.get("/reservations/{reservation_id}", response_model=schemas.Reservation)
async def get_reservation(reservation_id: int, db: Session = Depends(get_db)):
    reservation = db.query(models.Reservations).filter(models.Reservations.reservation_id == reservation_id).first()
    if reservation is None:
        raise HTTPException(status_code=404, detail="Reservation not found")

    return schemas.Reservation(
        id=reservation.reservation_id,
        user_id=reservation.user_id,
        publication_id=reservation.publication_id,
        created_at=reservation.created_at
    )


@app.post("/reservations", response_model=schemas.ReservationCreateOut, status_code=201)
async def create_reservation(reservation: schemas.ReservationCreate, db: Session = Depends(get_db)):

    user = db.query(models.Users).filter(models.Users.id == reservation.user_id).first()
    if user is None:
        raise HTTPException(status_code=404, detail="User not found")

    publication = db.query(models.Publications).filter(
        models.Publications.publication_id == reservation.publication_id).first()
    if publication is None:
        raise HTTPException(status_code=404, detail="Publication not found")

    reservation_id = reservation.id or uuid4()

    new_reservation = models.Reservations(
        reservation_id=reservation_id,
        user_id=reservation.user_id,
        publication_id=reservation.publication_id,
    )

    db.add(new_reservation)

    try:
        db.commit()
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=400, detail="Bad Request")

    return {
        "id": new_reservation.reservation_id,
        "user_id": new_reservation.user_id,
        "publication_id": new_reservation.publication_id,
        "created_at": new_reservation.created_at
    }


@app.delete("/reservations/{reservation_id}", status_code=204)
async def delete_reservation(reservation_id: UUID, db: Session = Depends(get_db)):
    reservation = db.query(models.Reservations).filter(models.Reservations.reservation_id == reservation_id).first()

    if reservation is None:
        raise HTTPException(status_code=404, detail="Reservation not found")

    db.delete(reservation)
    try:
        db.commit()
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=400, detail="Bad Request")


@app.post("/cards", response_model=schemas.CardsCreateOut, status_code=201)
async def create_card(card: schemas.CardsCreate, db: Session = Depends(get_db)):
    existing_user = db.query(models.Users).filter(models.Users.id == card.user_id).first()
    if existing_user is None:
        raise HTTPException(status_code=404, detail="User not found")

    card_id = card.id or uuid4()

    new_card = models.Cards(
        id=card_id,
        user_id=card.user_id,
        magstripe=card.magstripe,
        status=card.status
    )

    db.add(new_card)
    try:
        db.commit()
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=400, detail="Bad Request")

    return {
        "id": new_card.id,
        "user_id": new_card.user_id,
        "magstripe": new_card.magstripe,
        "status": new_card.status,
        "created_at": new_card.created_at,
        "updated_at": new_card.updated_at
    }


@app.get("/cards/{card_id}", response_model=schemas.CardsCreateOut)
async def get_card(card_id: UUID, db: Session = Depends(get_db)):
    card = db.query(models.Cards).filter(models.Cards.id == card_id).first()

    if not card:
        raise HTTPException(status_code=404, detail="Card not found")

    return schemas.CardsCreateOut.from_orm(card)


@app.patch("/cards/{user_id}", response_model=schemas.CardsCreateOut)
async def update_card(user_id: UUID, card_data: schemas.CardUpdate, db: Session = Depends(get_db)):
    card = db.query(models.Cards).filter(models.Cards.user_id == user_id).first()

    if not card:
        raise HTTPException(status_code=404, detail="Card not found")

    if card_data.status:
        card.status = card_data.status

    if card_data.user_id:
        user = db.query(models.Users).filter(models.Users.id == card_data.user_id).first()
        if not user:
            raise HTTPException(status_code=404, detail="User not found")
        card.user_id = card_data.user_id

    db.add(card)
    try:
        db.commit()
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=400, detail="Bad Request")

    updated_card = db.query(models.Cards).filter(models.Cards.user_id == user_id).first()
    return schemas.CardsCreateOut.from_orm(updated_card)


@app.delete("/cards/{card_id}", status_code=204)
async def delete_card(card_id: UUID, db: Session = Depends(get_db)):
    card = db.query(models.Cards).filter(models.Cards.id == card_id).first()

    if not card:
        raise HTTPException(status_code=404, detail="Card not found")

    db.delete(card)
    try:
        db.commit()
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=400, detail="Bad Request")


@app.post("/rentals", response_model=schemas.RentalCreateOut, status_code=201)
async def create_rental(rental: schemas.RentalCreate, db: Session = Depends(get_db)):

    existing_user = db.query(models.Users).filter(models.Users.id == rental.user_id).first()
    if existing_user is None:
        raise HTTPException(status_code=404, detail="User not found")

    if rental.duration > 14:
        raise HTTPException(status_code=404, detail="Duration too long")

    available_instance = db.query(models.PublicationInstances).filter(
        models.PublicationInstances.publication_id == rental.publication_id,
        models.PublicationInstances.status == 'available'
    ).first()

    if available_instance is None:
        raise HTTPException(status_code=404, detail="Publication not available")

    available_instance.status = 'borrowed'
    db.add(available_instance)

    rental_id = rental.id or uuid4()

    new_rental = models.Borrowings(
        borrowing_id=rental_id,
        user_id=rental.user_id,
        instance_id=available_instance.id,
        duration=rental.duration,
        start_date=func.now(),
        end_date=func.now() + timedelta(days=rental.duration),
    )

    db.add(new_rental)
    try:
        db.commit()
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=400, detail="Bad Request")

    return {
        "id": rental_id,
        "user_id": new_rental.user_id,
        "publication_instance_id": new_rental.instance_id,
        "duration": new_rental.duration,
        "start_date": new_rental.start_date,
        "end_date": new_rental.end_date,
        "status": new_rental.status
    }


@app.get("/rentals/{rental_id}", response_model=schemas.RentalCreateOut, status_code=200)
async def get_rental(rental_id: UUID, db: Session = Depends(get_db)):
    rental = db.query(models.Borrowings).filter(models.Borrowings.borrowing_id == rental_id).first()

    if not rental:
        raise HTTPException(status_code=404, detail="Rental not found")

    rental_out = schemas.RentalCreateOut.from_orm(rental)

    return {
        "id": rental_out.id,
        "user_id": rental_out.user_id,
        "publication_instance_id": rental_out.publication_instance_id,
        "duration": rental_out.duration,
        "start_date": rental_out.start_date,
        "end_date": rental_out.end_date,
        "status": rental_out.status
    }


@app.patch("/rentals/{rental_id}", response_model=schemas.RentalCreateOut, status_code=200)
async def update_rental(rental_id: UUID, rental_update: schemas.RentalUpdate, db: Session = Depends(get_db)):
    rental = db.query(models.Borrowings).filter(models.Borrowings.borrowing_id == rental_id).first()

    if not rental:
        raise HTTPException(status_code=404, detail="Rental not found")

    if rental.status != "active":
        raise HTTPException(status_code=400, detail="Rental is not active")

    if rental_update.duration is not None:
        if rental_update.duration <= 0 or rental_update.duration > 14:
            raise HTTPException(status_code=400, detail="Invalid duration")
        rental.duration = rental_update.duration
        rental.end_date = rental.start_date + timedelta(days=rental.duration)
        db.commit()

    rental_out = schemas.RentalCreateOut.from_orm(rental)

    return {
        "id": rental_out.id,
        "user_id": rental_out.user_id,
        "publication_instance_id": rental_out.publication_instance_id,
        "duration": rental_out.duration,
        "start_date": rental_out.start_date,
        "end_date": rental_out.end_date,
        "status": rental_out.status
    }


@app.post("/publications", response_model=schemas.PublicationCreateOut, status_code=201)
async def create_publication(publication: schemas.PublicationCreate, db: Session = Depends(get_db)):

    existing_publication = db.query(models.Publications).filter(
        models.Publications.publication_id == publication.id).first()
    if existing_publication:
        raise HTTPException(status_code=409, detail="Publication ID already exists")

    authors = []
    for author in publication.authors:
        db_author = db.query(models.Authors).filter(models.Authors.name == author.name, models.Authors.surname == author.surname).first()
        if db_author is None:
            raise HTTPException(status_code=404, detail="Author not found")
        authors.append(db_author)

    categories = []
    for category_name in publication.categories:
        db_category = db.query(models.Categories).filter(models.Categories.name == category_name).first()
        if db_category is None:
            raise HTTPException(status_code=404, detail="Category not found")
        categories.append(db_category)

    publication_id = publication.id or uuid4()
    new_publication = models.Publications(
        publication_id=publication_id,
        title=publication.title)
    db.add(new_publication)
    db.commit()
    db.refresh(new_publication)

    for author in authors:
        pub_author = models.PublicationAuthors(publication_id=new_publication.publication_id,
                                               author_id=author.id)
        db.add(pub_author)
        db.commit()

    for category in categories:
        pub_category = models.PublicationCategories(publication_id=new_publication.publication_id,
                                                    category_id=category.id)
        db.add(pub_category)
        db.commit()

    response = schemas.PublicationCreateOut(
        id=new_publication.publication_id,
        title=new_publication.title,
        authors=publication.authors,
        categories=publication.categories,
        created_at=new_publication.created_at,
        updated_at=new_publication.updated_at,
    )
    return response


@app.get("/publications/{publication_id}", response_model=schemas.PublicationCreateOut)
async def get_publication(publication_id: UUID, db: Session = Depends(get_db)):
    publication = db.query(models.Publications).filter(models.Publications.publication_id == publication_id).first()
    if not publication:
        raise HTTPException(status_code=404, detail="Publication not found")

    authors = db.query(models.Authors).join(models.PublicationAuthors).filter(models.PublicationAuthors.publication_id == publication.publication_id).all()
    categories = db.query(models.Categories).join(models.PublicationCategories).filter(models.PublicationCategories.publication_id == publication.publication_id).all()

    author_list = [schemas.Author(name=author.name, surname=author.surname) for author in authors]
    category_list = [category.name for category in categories]

    response = schemas.PublicationCreateOut(
        id=publication.publication_id,
        title=publication.title,
        authors=author_list,
        categories=category_list,
        created_at=publication.created_at,
        updated_at=publication.updated_at,
    )
    return response


@app.patch("/publications/{publication_id}", response_model=schemas.PublicationCreateOut)
async def update_publication(publication_id: UUID, publication: schemas.PublicationCreate, db: Session = Depends(get_db)):

    db_publication = db.query(models.Publications).filter(models.Publications.publication_id == publication_id).first()
    if not db_publication:
        raise HTTPException(status_code=404, detail="Publication not found")

    if publication.title:
        db_publication.title = publication.title

    if publication.authors:

        db.query(models.PublicationAuthors).filter(models.PublicationAuthors.publication_id == publication_id).delete()

        for author in publication.authors:
            db_author = db.query(models.Authors).filter(models.Authors.name == author.name, models.Authors.surname == author.surname).first()
            if db_author is None:
                raise HTTPException(status_code=404, detail="Author not found")

            pub_author = models.PublicationAuthors(publication_id=publication_id, author_id=db_author.id)
            db.add(pub_author)

    if publication.categories:

        db.query(models.PublicationCategories).filter(models.PublicationCategories.publication_id == publication_id).delete()

        for category_name in publication.categories:
            db_category = db.query(models.Categories).filter(models.Categories.name == category_name).first()
            if db_category is None:
                raise HTTPException(status_code=404, detail="Category not found")

            pub_category = models.PublicationCategories(publication_id=publication_id, category_id=db_category.id)
            db.add(pub_category)

    db.commit()
    db.refresh(db_publication)

    authors = db.query(models.Authors).join(models.PublicationAuthors).filter(models.PublicationAuthors.publication_id == publication_id).all()
    categories = db.query(models.Categories).join(models.PublicationCategories).filter(models.PublicationCategories.publication_id == publication_id).all()

    author_list = [schemas.Author(name=author.name, surname=author.surname) for author in authors]
    category_list = [category.name for category in categories]

    response = schemas.PublicationCreateOut(
        id=db_publication.publication_id,
        title=db_publication.title,
        authors=author_list,
        categories=category_list,
        created_at=db_publication.created_at,
        updated_at=db_publication.updated_at,
    )
    return response


@app.delete("/publications/{publication_id}", status_code=204)   # also deletes all the corresponding publication_id instances in other tables
async def delete_publication(publication_id: UUID, db: Session = Depends(get_db)):

    db_publication = db.query(models.Publications).filter(models.Publications.publication_id == publication_id).first()
    if not db_publication:
        raise HTTPException(status_code=404, detail="Publication not found")

    db.query(models.PublicationAuthors).filter(models.PublicationAuthors.publication_id == publication_id).delete()
    db.query(models.PublicationCategories).filter(models.PublicationCategories.publication_id == publication_id).delete()
    db.query(models.PublicationInstances).filter(models.PublicationInstances.publication_id == publication_id).delete()
    db.query(models.PublicationSpecialTitles).filter(models.PublicationSpecialTitles.publication_id == publication_id).delete()
    db.query(models.Reviews).filter(models.Reviews.publication_id == publication_id).delete()
    db.query(models.Reservations).filter(models.Reservations.publication_id == publication_id).delete()
    db.query(models.PersonalReadingList).filter(models.PersonalReadingList.publication_id == publication_id).delete()

    db.delete(db_publication)
    try:
        db.commit()
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=400, detail="Bad Request")


@app.post("/instances", response_model=schemas.PublicationInstanceCreateOut, status_code=201)
async def create_publication_instance(instance: schemas.PublicationInstanceCreate, db: Session = Depends(get_db)):
    existing_publication = db.query(models.Publications).filter(models.Publications.publication_id == instance.publication_id).first()
    if existing_publication is None:
        raise HTTPException(status_code=404, detail="Publication not found")

    instance_id = instance.id or uuid4()

    new_instance = models.PublicationInstances(
        id=instance_id,
        publication_id=instance.publication_id,
        type=instance.type,
        publisher=instance.publisher,
        year=instance.year,
        status=instance.status,
    )

    db.add(new_instance)
    try:
        db.commit()
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=400, detail="Bad Request")

    return {
        "id": new_instance.id,
        "type": new_instance.type,
        "publisher": new_instance.publisher,
        "year": new_instance.year,
        "status": new_instance.status,
        "publication_id": new_instance.publication_id,
        "created_at": new_instance.created_at,
        "updated_at": new_instance.updated_at
    }


@app.get("/instances/{instance_id}", response_model=schemas.PublicationInstanceCreateOut, status_code=200)
async def get_publication_instance(instance_id: UUID, db: Session = Depends(get_db)):
    instance = db.query(models.PublicationInstances).filter(models.PublicationInstances.id == instance_id).first()

    if not instance:
        raise HTTPException(status_code=404, detail="Publication instance not found")

    instance_out = schemas.PublicationInstanceCreateOut.from_orm(instance)

    return {
        "id": instance_out.id,
        "type": instance_out.type,
        "publisher": instance_out.publisher,
        "year": instance_out.year,
        "status": instance_out.status,
        "publication_id": instance_out.publication_id,
        "created_at": instance_out.created_at,
        "updated_at": instance_out.updated_at
    }


@app.patch("/instances/{instance_id}", response_model=schemas.PublicationInstanceCreateOut, status_code=200)
async def update_publication_instance(instance_id: UUID, instance_update: schemas.PublicationInstanceUpdate, db: Session = Depends(get_db)):
    instance = db.query(models.PublicationInstances).filter(models.PublicationInstances.id == instance_id).first()

    if not instance:
        raise HTTPException(status_code=404, detail="Publication instance not found")

    for field, value in instance_update:
        if value is not None:
            setattr(instance, field, value)

    try:
        db.commit()
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=400, detail="Bad Request")

    instance_out = schemas.PublicationInstanceCreateOut.from_orm(instance)

    return {
        "id": instance_out.id,
        "type": instance_out.type,
        "publisher": instance_out.publisher,
        "year": instance_out.year,
        "status": instance_out.status,
        "publication_id": instance_out.publication_id,
        "created_at": instance_out.created_at,
        "updated_at": instance_out.updated_at
    }


@app.delete("/instances/{instance_id}", status_code=204)
async def delete_instance(instance_id: UUID, db: Session = Depends(get_db)):

    db_instance = db.query(models.PublicationInstances).filter(models.PublicationInstances.id == instance_id).first()
    if not db_instance:
        raise HTTPException(status_code=404, detail="Instance not found")

    db.query(models.Borrowings).filter(models.Borrowings.instance_id == instance_id).delete()

    db.delete(db_instance)
    try:
        db.commit()
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=400, detail="Bad Request")
    return {}


@app.post("/authors", response_model=schemas.CreateAuthorOut, status_code=201)
async def create_author(author: schemas.CreateAuthor, db: Session = Depends(get_db)):
    existing_author = db.query(models.Authors).filter(models.Authors.name == author.name, models.Authors.surname == author.surname).first()
    if existing_author:
        raise HTTPException(status_code=409, detail="Author already exists")

    author_id = author.id or uuid4()

    new_author = models.Authors(
        id=author_id,
        name=author.name,
        surname=author.surname
    )

    db.add(new_author)
    try:
        db.commit()
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=400, detail="Bad Request")

    return {
        "id": new_author.id,
        "name": new_author.name,
        "surname": new_author.surname,
        "created_at": new_author.created_at,
        "updated_at": new_author.updated_at
    }


@app.get("/authors/{author_id}", response_model=schemas.GetAuthor)
async def get_author(author_id: UUID, db: Session = Depends(get_db)):
    author = db.query(models.Authors).filter(models.Authors.id == author_id).first()

    if not author:
        raise HTTPException(status_code=404, detail="Author not found")

    return {
        "id": author.id,
        "name": author.name,
        "surname": author.surname,
        "created_at": author.created_at,
        "updated_at": author.updated_at
    }


@app.patch("/authors/{author_id}", response_model=schemas.GetAuthor)
async def update_author(author_id: UUID, author_data: schemas.UpdateAuthor, db: Session = Depends(get_db)):

    author = db.query(models.Authors).filter(models.Authors.id == author_id).first()

    if not author:
        raise HTTPException(status_code=404, detail="Author not found")

    if author_data.name is not None:
        author.name = author_data.name

    if author_data.surname is not None:
        author.surname = author_data.surname

    try:
        db.commit()
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=400, detail="Bad Request")

    author_out = schemas.GetAuthor.from_orm(author)

    return author_out

from fastapi import HTTPException


@app.delete("/authors/{author_id}", response_model=schemas.GetAuthor)
async def delete_author(author_id: UUID, db: Session = Depends(get_db)):

    author = db.query(models.Authors).filter(models.Authors.id == author_id).first()

    if not author:
        raise HTTPException(status_code=404, detail="Author not found")

    db.delete(author)
    db.commit()

    author_out = schemas.GetAuthor.from_orm(author)
    return author_out


@app.post("/categories", response_model=schemas.CreateCategoryOut, status_code=201)
async def create_category(category: schemas.CreateCategory, db: Session = Depends(get_db)):
    existing_category = db.query(models.Categories).filter(models.Categories.name == category.name).first()

    if existing_category:
        raise HTTPException(status_code=409, detail="Category already exists")

    category_id = category.id or uuid4()

    new_category = models.Categories(
        id=category_id,
        name=category.name,
    )

    db.add(new_category)
    try:
        db.commit()
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=400, detail="Bad Request")

    return {
        "id": category_id,
        "name": new_category.name,
        "created_at": new_category.created_at,
        "updated_at": new_category.updated_at
    }


@app.get("/categories/{category_id}", response_model=schemas.CreateCategoryOut, status_code=201)
async def get_category(category_id: UUID, db: Session = Depends(get_db)):
    category = db.query(models.Categories).filter(models.Categories.id == category_id).first()

    if not category:
        raise HTTPException(status_code=404, detail="Category not found")

    return {
        "id": category.id,
        "name": category.name,
        "created_at": category.created_at,
        "updated_at": category.updated_at
    }


@app.patch("/categories/{category_id}", response_model=schemas.CreateCategoryOut)
async def update_category(category_id: UUID, category: schemas.CreateCategory, db: Session = Depends(get_db)):
    db_category = db.query(models.Categories).filter(models.Categories.id == category_id).first()
    if db_category is None:
        raise HTTPException(status_code=404, detail="Category not found")

    if category.name:
        db_category.name = category.name

    try:
        db.commit()
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=400, detail="Bad Request")

    return db_category


@app.delete("/categories/{category_id}", status_code=204)
async def delete_category(category_id: UUID, db: Session = Depends(get_db)):
    category = db.query(models.Categories).filter(models.Categories.id == category_id).first()
    if category is None:
        raise HTTPException(status_code=404, detail="Category not found")

    db.delete(category)
    try:
        db.commit()
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=400, detail="Bad Request")
