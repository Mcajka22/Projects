from pydantic import BaseSettings


class Settings(BaseSettings):
    class Config:
        case_sensitive = True

    DATABASE_HOST: str = "127.0.0.1"
    DATABASE_PORT: str = "5432"
    DATABASE_NAME: str = "dbs_5"
    DATABASE_USER: str = "postgres"
    DATABASE_PASSWORD: str = "postgres"


settings = Settings()
