from scapy.all import *
import json
import ruamel.yaml
from ruamel.yaml.scalarstring import LiteralScalarString


yml = ruamel.yaml.YAML()
name = "Martin Cajka"
pcapFileName = 'z1-final.pcap'                                  # string na konkretny nazov analyzovaneho pcap suboru
packets = rdpcap("./vzorky_pcap_na_analyzu/" + pcapFileName)    # nacitanie pcap suboru do premennej packets

with open('AnalysisData.json') as json_file:                    # otvorenie json filu s dictionaries
    ANALYSIS_DATA = json.load(json_file)

outputDictsLists = []
outputAllSenders = []
ARPFrameInfoList = []
TFTPFrameInfoList = []
TFTPCommsList = []


class Frame:                                                # trieda frame, ma atributy pre cielove parametre frame-u
    def __init__(self, frameNum):
        self.frame_number = frameNum
        self.len_frame_pcap = 0
        self.len_frame_medium = 0
        self.frame_type = ""
        self.src_mac = ""
        self.dst_mac = ""
        self.ether_type = None
        self.sap = None
        self.pid = None
        self.src_ip = None
        self.dst_ip = None
        self.protocol = None
        self.src_port = None
        self.dst_port = None
        self.app_protocol = None
        self.arp_opcode = None
        self.hexa_frame = ""

    def setAttributes(self, frame):        # funkcia sluziacia na nastavenie attributov pre frame, vola alebo obsahuje vypoctove funkcie pre jednotlive attributy
        self.len_frame_pcap = int(len(frame)/2)
        self.len_frame_medium = max(self.len_frame_pcap+4, 64)      # minimalna velkost 64, vzdy sa pripocitava + 4
        self.frame_type = readFrameType(frame)

        if frame[0:12] == "01000c000000" or frame[0:12] == "03000c000000":  # ak je to ISL Frame
            if self.frame_type == "IEEE 802.3 LLC":
                if frame[82:84] in ANALYSIS_DATA["SAPS"]:
                    self.sap = (ANALYSIS_DATA["SAPS"][frame[82:84]])
            if self.frame_type == "IEEE 802.3 LLC & SNAP":
                if frame[92:96] in (ANALYSIS_DATA["PIDS"]):
                    self.pid = (ANALYSIS_DATA["PIDS"][frame[92:96]])
            self.dst_mac = str(frame[52:54]) + ":" + str(frame[54:56]) + ":" + str(frame[56:58]) + ":" + str(frame[58:60]) + ":" + str(frame[60:62]) + ":" + str(frame[62:64])
            self.src_mac = str(frame[64:66]) + ":" + str(frame[66:68]) + ":" + str(frame[68:70]) + ":" + str(frame[70:72]) + ":" + str(frame[72:74]) + ":" + str(frame[74:76])
            self.hexa_frame = setHexaFrame(frame)
        else:
            if self.frame_type == "IEEE 802.3 LLC":
                if frame[30:32] in ANALYSIS_DATA["SAPS"]:
                    self.sap = (ANALYSIS_DATA["SAPS"][frame[30:32]])
            if self.frame_type == "IEEE 802.3 LLC & SNAP":
                if frame[40:44] in (ANALYSIS_DATA["PIDS"]):
                    self.pid = (ANALYSIS_DATA["PIDS"][frame[40:44]])
            self.dst_mac = str(frame[0:2]) + ":" + str(frame[2:4]) + ":" + str(frame[4:6]) + ":" + str(frame[6:8]) + ":" + str(frame[8:10]) + ":" + str(frame[10:12])
            self.src_mac = str(frame[12:14]) + ":" + str(frame[14:16]) + ":" + str(frame[16:18]) + ":" + str(frame[18:20]) + ":" + str(frame[20:22]) + ":" + str(frame[22:24])

            if self.frame_type == "ETHERNET II":  # úloha 2
                self.setEthernetIIInfo(frame)
            self.hexa_frame = setHexaFrame(frame)

    def printAttributes(self):              # print attributov framu do konzole
        print("Frame Number: " + str(self.frame_number))
        print("Frame Length pcap: " + str(self.len_frame_pcap))
        print("Frame Length medium: " + str(self.len_frame_medium))
        print("Frame Type: " + str(self.frame_type))
        if self.frame_type == "IEEE 802.3 LLC":
            print("LCC Service Access Point: " + str(self.sap))
        if self.frame_type == "IEEE 802.3 LLC & SNAP":
            print("LCC & SNAP PID: " + str(self.pid))
        print("Destination MAC Address: " + str(self.dst_mac))
        print("Source MAC Address: " + str(self.src_mac))
        if self.frame_type == "ETHERNET II":
            print("Ether Type: " + str(self.ether_type))
        if self.ether_type == "ARP" or self.ether_type == "IPv4":
            print("Sender IP: " + str(self.src_ip))
            print("Target IP: " + str(self.dst_ip))
            if self.ether_type == "IPv4":
                print("Protocol: " + str(self.protocol))
                if self.protocol == "UDP" or self.protocol == "TCP":
                    print("Source port: " + str(self.src_port))
                    print("Destination port: " + str(self.dst_port))
                    print("App Protocol: " + str(self.app_protocol))

        print("Hexa Frame: \n" + self.hexa_frame)

    def setEthernetIIInfo(self, frame):
        if frame[24:28] in (ANALYSIS_DATA["ETHER_TYPES"]):
            self.ether_type = (ANALYSIS_DATA["ETHER_TYPES"][frame[24:28]])

        if self.ether_type == "ARP":
            self.src_ip = str(int(frame[56:58], 16)) + "." + str(int(frame[58:60], 16)) + "." + str(int(frame[60:62], 16)) + "." + str(int(frame[62:64], 16))
            self.dst_ip = str(int(frame[76:78], 16)) + "." + str(int(frame[78:80], 16)) + "." + str(int(frame[80:82], 16)) + "." + str(int(frame[82:84], 16))
            if frame[42:44] in ANALYSIS_DATA["ARP_OPCODE"]:
                self.arp_opcode = ANALYSIS_DATA["ARP_OPCODE"][frame[42:44]]

        if self.ether_type == "IPv4":
            self.src_ip = str(int(frame[52:54], 16)) + "." + str(int(frame[54:56], 16)) + "." + str(int(frame[56:58], 16)) + "." + str(int(frame[58:60], 16))
            self.dst_ip = str(int(frame[60:62], 16)) + "." + str(int(frame[62:64], 16)) + "." + str(int(frame[64:66], 16)) + "." + str(int(frame[66:68], 16))

            if frame[46:48] in (ANALYSIS_DATA["IPV4_PROTOCOL"]):
                self.protocol = (ANALYSIS_DATA["IPV4_PROTOCOL"][frame[46:48]])

            if self.protocol == "UDP" or self.protocol == "TCP":

                self.src_port = int(frame[68:72], 16)
                self.dst_port = int(frame[72:76], 16)

                if str(int(frame[68:72], 16)) in (ANALYSIS_DATA["TCP_UDP_PORTS"]):
                    self.app_protocol = ANALYSIS_DATA["TCP_UDP_PORTS"][str(int(frame[68:72], 16))]
                if str(int(frame[72:76], 16)) in (ANALYSIS_DATA["TCP_UDP_PORTS"]):
                    self.app_protocol = ANALYSIS_DATA["TCP_UDP_PORTS"][str(int(frame[72:76], 16))]

    def setYamlOutput(self):

        frameInfo = {
                    "frame_number": self.frame_number,
                    "len_frame_pcap": self.len_frame_pcap,
                    "len_frame_medium": self.len_frame_medium,
                    "frame_type": self.frame_type,
                    "src_mac": self.src_mac,
                    "dst_mac": self.dst_mac,
                     }

        if self.ether_type is not None:
            frameInfo["ether_type"] = self.ether_type
        if self.sap is not None:
            frameInfo["sap"] = self.sap
        if self.pid is not None:
            frameInfo["pid"] = self.pid
        if self.src_ip is not None:
            frameInfo["src_ip"] = self.src_ip
        if self.dst_ip is not None:
            frameInfo["dst_ip"] = self.dst_ip
        if self.protocol is not None:
            frameInfo["protocol"] = self.protocol
        if self.src_port is not None:
            frameInfo["src_port"] = self.src_port
        if self.dst_port is not None:
            frameInfo["dst_port"] = self.dst_port
        if self.app_protocol is not None:
            frameInfo["app_protocol"] = self.app_protocol

        frameInfo["hexa_frame"] = self.hexa_frame
        return frameInfo


def readFrameType(frame):              # vrati frame type
    temp = int(frame[24:28], 16)        # prevod na dekadicky format

    if temp >= 1536:
        return "ETHERNET II"
    else:
        if frame[30:32] == "aa":
            return "IEEE 802.3 LLC & SNAP"
        elif frame[30:32] == "ff":
            return "IEEE 802.3 RAW"
        else:
            return "IEEE 802.3 LLC"


def setHexaFrame(frame):  # upravi frame na pozadovany hexa vystup
    count = 1

    hexFormat = ""

    for char in frame:

        hexFormat += str(char)

        if count % 2 == 0 and count % 32 != 0 and count != len(frame):
            hexFormat += " "
        if count % 32 == 0:
            hexFormat += "\n"
        if count == len(frame) and count % 32 != 0:
            hexFormat += "\n"
        count += 1

    return LiteralScalarString(hexFormat)


def getARPcomms():    # matchovanie arp komunikacii a yaml vypis
    completeCommsCounter = 0
    partialCommsCounter = 0
    requestsList = []
    repliesList = []
    ARPCompleteComms = []
    ARPPartialComms = []

    for frame in ARPFrameInfoList:

        if frame.arp_opcode == "REQUEST":

            requestsList.append(frame)

            for reply in repliesList:
                completeARPList = []
                if reply.src_ip == frame.dst_ip:
                    completeCommsCounter += 1
                    outputARPFrameRequest = setARPFrameYAML(frame)
                    outputARPFrameReply = setARPFrameYAML(reply)
                    completeARPList.append(outputARPFrameRequest)
                    completeARPList.append(outputARPFrameReply)
                    completeARPComms = {"number_comm": completeCommsCounter, "src_comm": frame.src_ip, "dst_comm": frame.dst_ip,
                                        "packets": completeARPList}
                    ARPCompleteComms.append(completeARPComms)
                    repliesList.remove(reply)
                    requestsList.pop()

        if frame.arp_opcode == "REPLY":

            repliesList.append(frame)

            for request in requestsList:
                completeARPList = []
                if request.dst_ip == frame.src_ip:
                    completeCommsCounter += 1
                    outputARPFrameRequest = setARPFrameYAML(request)
                    outputARPFrameReply = setARPFrameYAML(frame)
                    completeARPList.append(outputARPFrameRequest)
                    completeARPList.append(outputARPFrameReply)
                    completeARPComms = {"number_comm": completeCommsCounter, "src_comm": request.src_ip,
                                        "dst_comm": request.dst_ip,
                                        "packets": completeARPList}

                    ARPCompleteComms.append(completeARPComms)
                    requestsList.remove(request)
            repliesList.pop()

    for i in requestsList:
        partialCommsCounter += 1
        outputARPPartial = setARPFrameYAML(i)
        tempValidatorList = [outputARPPartial]
        partialComm = {"number_comm": partialCommsCounter, "packets": tempValidatorList}
        ARPPartialComms.append(partialComm)

    for i in repliesList:
        partialCommsCounter += 1
        outputARPPartial = setARPFrameYAML(i)
        tempValidatorList = [outputARPPartial]
        partialComm = {"number_comm": partialCommsCounter, "packets": tempValidatorList}
        ARPPartialComms.append(partialComm)

    outputARPDict = {"name": name, "pcap_name": pcapFileName, "filter_name": "ARP", "complete_comms": ARPCompleteComms,
                     "partial_comms": ARPPartialComms}
    return outputARPDict


def setARPFrameYAML(obj):
    tempDict = {
            "frame_number": obj.frame_number,
            "len_frame_pcap": obj.len_frame_pcap,
            "len_frame_medium": obj.len_frame_medium,
            "frame_type": obj.frame_type,
            "src_mac": obj.src_mac,
            "dst_mac": obj.dst_mac,
            "ether_type": obj.ether_type,
            "arp_opcode": obj.arp_opcode,
            "src_ip": obj.src_ip,
            "dst_ip": obj.dst_ip,
            "hexa_frame": obj.hexa_frame
        }
    return tempDict


def getInputFromMenu():

    print("1. Print all frames: ")
    print("2. Use TFTP Filter: ")
    print("3. Use ARP Filter: ")
    print("4. Use HTTP Filter: (not implemented)")
    print("5. Use HTTPS Filter: (not implemented)")
    print("6. Use SSH Filter: (not implemented)")
    print("7. Use FTP-Control Filter: (not implemented)")
    print("8. Use FTP-Data Filter: (not implemented)")
    print("9. Use ICMP Filter: (not implemented)")
    print("0. Exit Program...")

    userInput = int(input("Enter the number corresponding to desired output: "))
    return userInput


def getTFTPcomms(TFTPlist, counter):

    TFTPcommCounter = counter
    TFTPpacketsList = []
    notCommunicatingPackets = []

    flag = 0
    src_comm = 0
    dst_comm = 0
    commSrcPort = 0

    if bool(TFTPlist) is False:
        return

    else:

        for frame in TFTPlist:
            if frame.dst_port == 69:
                commSrcPort = frame.src_port
                src_comm = frame.src_ip
                dst_comm = frame.dst_ip
                break

        for frame in TFTPlist:
            if frame.dst_port == 69:
                flag = 1

            if flag == 1:
                if frame.src_port == commSrcPort or frame.dst_port == commSrcPort:

                    TFTPpacketDict = {
                        "frame_number": frame.frame_number,
                        "len_frame_pcap": frame.len_frame_pcap,
                        "len_frame_medium": frame.len_frame_medium,
                        "frame_type": frame.frame_type,
                        "src_mac": frame.src_mac,
                        "dst_mac": frame.dst_mac,
                        "hexa_frame": frame.hexa_frame,
                        "ether_type": frame.ether_type,
                        "src_ip": frame.src_ip,
                        "dst_ip": frame.dst_ip,
                        "protocol": frame.protocol,
                        "app_protocol": frame.app_protocol,
                        "src_port": frame.src_port,
                        "dst_port": frame.dst_port
                    }
                    TFTPpacketsList.append(TFTPpacketDict)

                else:
                    notCommunicatingPackets.append(frame)

        if bool(TFTPpacketsList) is not False:
            TFTPCommsList.append({"number_comm": TFTPcommCounter, "src_comm": src_comm, "dst_comm": dst_comm, "packets": TFTPpacketsList})

        getTFTPcomms(notCommunicatingPackets, TFTPcommCounter+1)

        outputTFTPDict = {"name": name, "pcap_name": pcapFileName, "complete_comms": TFTPCommsList}

        return outputTFTPDict


def main():
    TFTPcomm = 0
    i = 1
    ipDict = {}

    for sPacket in packets:                    # prechadzanie frame-ami

        frame = raw(sPacket).hex()             # vrati bytovu reprezentiaciu packetu v hex formate

        obj = Frame(i)                         # tvorba objektu z daného frame-u
        obj.setAttributes(frame)               # priposvanie attribútov

        if obj.ether_type == "IPv4":                  # Uloha 3 IP counter
            if obj.src_ip not in ipDict.keys():
                ipDict[obj.src_ip] = 1
            else:
                ipDict[obj.src_ip] += 1

        if obj.dst_port == 69:
            TFTPcomm = 1

        if TFTPcomm == 1:
            if obj.protocol == "UDP":
                TFTPFrameInfoList.append(obj)

        yamlFrameOutput = obj.setYamlOutput()
        outputDictsLists.append(yamlFrameOutput)

        if obj.ether_type == "ARP":
            ARPFrameInfoList.append(obj)

        # obj.printAttributes()

        i += 1

    maxSender = max(ipDict, key=ipDict.get)
    maxSent = ipDict[maxSender]

    maxSendersList = []
    for ip in ipDict:                   # cyklenie ipckami v ip counter dictionary
        setYamlOutputIPs = {"node": ip, "number_of_sent_packets": ipDict[ip]}
        outputAllSenders.append(setYamlOutputIPs)

        if ipDict[ip] == maxSent:         # hladanie vsetkych najvacsich odosielatelov
            maxSendersList.append(ip)

    while 1:

        userInput = getInputFromMenu()

        if userInput == 1:

            outputDict = {"name": name, "pcap_name": pcapFileName, "packets": outputDictsLists,
                          "ipv4_senders": outputAllSenders,
                          "max_send_packets_by": maxSendersList}

            with open("output.yaml", "w") as yamlFile:
                yml.dump(outputDict, yamlFile)

        elif userInput == 2:

            outputTFTPDict = getTFTPcomms(TFTPFrameInfoList, 1)
            with open("outputTFTP.yaml", "w") as yamlFile:
                yml.dump(outputTFTPDict, yamlFile)

        elif userInput == 3:

            outputARPDict = getARPcomms()
            with open("outputARP.yaml", "w") as yamlFile:
                yml.dump(outputARPDict, yamlFile)

        elif userInput == 0:
            return

        else:
            print("Incorrect input or the functionality is not implemented!")


main()
