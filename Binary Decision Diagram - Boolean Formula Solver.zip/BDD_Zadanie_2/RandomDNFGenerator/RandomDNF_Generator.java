package RandomDNFGenerator;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class RandomDNF_Generator {
    int numOfVariables;
    Random random;
    char[] variables;

    public RandomDNF_Generator(int numOfVariables){
        this.numOfVariables = numOfVariables;
        random = new Random();
        variables = new char[numOfVariables];
        
        char letter = 'A';
        
        for (int i=0; i<numOfVariables; i++){
            variables[i] = letter;
            letter++;
        }
    }

    public String generateRandomString(){

        List<String> formulaMembers = new ArrayList<String>();

        for (int j=0; j<this.numOfVariables + random.nextInt(4); j++){

        String member = "";

            for (int i=0; i<this.numOfVariables; i++){

                if (random.nextBoolean()){ //boolean to decide if to add index variable to member of boolean expression

                    if (member == ""){      //if adding first character
                        if (random.nextBoolean()){      //possibilty of adding negation
                            member = member + "!" + this.variables[i];
                        } else{
                            member = member + this.variables[i];    //adding index variable to first place of member
                        }
                    }
                    else{
                        if (random.nextBoolean()){      //possibilty of adding negation
                            member = member + ".!" + this.variables[i];
                        } else {
                            member = member + "." + this.variables[i]; //adding index variable
                        }
                    }
                }
            }
            formulaMembers.add(member);
        }

        String generatedString = "";

        for (int i = 0; i < formulaMembers.size(); i++) {
            if (formulaMembers.get(i) ==""){
                continue;
            }
            if (generatedString == ""){
                generatedString = formulaMembers.get(i);
            }
            else {
                generatedString = generatedString + "+" + formulaMembers.get(i);
            }
        }
        return generatedString;
    }


    public String generateCompleteString(){
        List<String> formulaMembers = new ArrayList<String>();

        for (int j=0; j<this.numOfVariables; j++){
            String member = "";

            for (int i=0; i<this.numOfVariables; i++){

                if (member == ""){      //if adding first character
                    if (random.nextBoolean()){      //possibilty of adding negation
                        member = member + "!" + this.variables[i];
                    } else{
                        member = member + this.variables[i];    //adding index variable to first place of member
                    }
                }
                else{
                    if (random.nextBoolean()){      //possibilty of adding negation
                        member = member + ".!" + this.variables[i];
                    } else {
                        member = member + "." + this.variables[i]; //adding index variable
                    }
                }
            }
            formulaMembers.add(member);
        }
        String generatedString = "";

        for (int i = 0; i < formulaMembers.size(); i++) {
            if (formulaMembers.get(i) ==""){
                continue;
            }
            if (generatedString == ""){
                generatedString = formulaMembers.get(i);
            }
            else {
                generatedString = generatedString + "+" + formulaMembers.get(i);
            }
        }
        return generatedString;
    }
}
