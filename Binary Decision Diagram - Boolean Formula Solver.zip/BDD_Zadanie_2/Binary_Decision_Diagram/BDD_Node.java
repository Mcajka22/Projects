package Binary_Decision_Diagram;

public class BDD_Node {

    public char currCharacter;
    public boolean isCounted = false;
    public String node_bFunction;
    public String nodeOrder;
    public BDD_Node nextNode = null;
    public BDD_Node parent = null;
    public BDD_Node leftChild_0 = null;
    public BDD_Node rightChild_1 = null;

    public BDD_Node(){

    }
}
