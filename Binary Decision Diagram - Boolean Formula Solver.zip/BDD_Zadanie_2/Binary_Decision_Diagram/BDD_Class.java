package Binary_Decision_Diagram;

import java.util.*;

public class BDD_Class {
    int numOfVariables;
    int actualNumOfNodes = 0;
    int expectedNumOfNodes;
    private BDD_Node headNode = null;
    static BDD_Node zeroNode;
    static BDD_Node oneNode;
    ArrayList<HashMap<Integer, BDD_Node>> hashTableList = new ArrayList<HashMap<Integer, BDD_Node>>();

    public BDD_Class(){
        this.headNode = new BDD_Node();

        zeroNode = new BDD_Node();
        zeroNode.node_bFunction = "0";

        oneNode = new BDD_Node();
        oneNode.node_bFunction = "1";
    }

    //method to create a BDD tree
    public BDD_Node BDD_create(String b_Function, String b_Order){
        this.numOfVariables = b_Order.length();
        this.expectedNumOfNodes = (int)Math.pow(2, this.numOfVariables+1)-1;

        for (int i = 0; i <= this.numOfVariables; i++) {         //initializing the hashMaps for each level
            hashTableList.add(new HashMap<Integer, BDD_Node>());
        }

        recursiveBDD_create(b_Function, b_Order, this.getHeadNode());   //recursive BDD creation function for a formula in DNF format

        this.actualNumOfNodes = 0;

        countActualNodes(this.getHeadNode());

        float reductionPercentage = (100 - ((float)this.actualNumOfNodes/(float)this.expectedNumOfNodes)*100);

        System.out.println("Order: " + b_Order + " Reduction Percentage: " + this.actualNumOfNodes + "/" + this.expectedNumOfNodes + " = " + String.format("%.2f", reductionPercentage) + "%");

        return this.getHeadNode();
    }

    //recursive BDD creation function for a formula in DNF format
    public BDD_Node recursiveBDD_create(String b_Function, String b_Order, BDD_Node currNode){

        currNode.node_bFunction = b_Function;       //assign the formula to node
        currNode.nodeOrder = b_Order;       //assign the order to node

        currNode.currCharacter = b_Order.charAt(0);     //separate the first character of the order that will be used for replacement
        String remainingOrder = b_Order.substring(1);      //and remember the remaining order for recursion

        String leftChildFormula = solveLeftChild(currNode.currCharacter, currNode);     //solve the DNF formula for the left child
        String rightChildFormula = solveRightChild(currNode.currCharacter, currNode);   //solve the DNF formula for the right child

        //S reduction using array list of HashMaps, each layer has its own hash map
        int hash = getHash(currNode.node_bFunction);
        HashMap<Integer, BDD_Node> indexHashMap = hashTableList.get(currNode.currCharacter - 'A');
        BDD_Node indexNode = indexHashMap.get(hash);

        if (indexNode == null){                    //case the index is empty we can just put node in, no reduction
            indexHashMap.put(hash, currNode);
        }
        else {                                     //else we search for a node with the same boolean formula
            while (indexNode != null){
                if (indexNode.node_bFunction.equals(currNode.node_bFunction)){  //if we find it we can go onto reduction

                    if (currNode.parent.leftChild_0 == currNode){        //the already created node replaces the current node as it is the same
                        currNode.parent.leftChild_0 = indexNode;
                    } else{
                        currNode.parent.rightChild_1 = indexNode;
                    }
                    return indexNode;
                }
                if (indexNode.nextNode == null){      //if it was not found and a null node is reached, we chain node
                    indexNode.nextNode = currNode;
                    break;
                }
                indexNode = indexNode.nextNode;
            }
        }

        if (leftChildFormula.equals("0")){
            currNode.leftChild_0 = this.zeroNode;

        } else if (leftChildFormula.equals("1")) {
            currNode.leftChild_0 = this.oneNode;

        } else{
            currNode.leftChild_0 = new BDD_Node();
            currNode.leftChild_0.parent = currNode;
            recursiveBDD_create(leftChildFormula, remainingOrder, currNode.leftChild_0);
        }

        if (rightChildFormula.equals("0")){
            currNode.rightChild_1 = this.zeroNode;

        } else if (rightChildFormula.equals("1")) {
            currNode.rightChild_1 = this.oneNode;

        } else{
            currNode.rightChild_1 = new BDD_Node();
            currNode.rightChild_1.parent = currNode;
            recursiveBDD_create(rightChildFormula, remainingOrder, currNode.rightChild_1);
        }

        return currNode;
    }

    public BDD_Node BDD_create_with_best_order(String b_Function){
        Set<Character> b_FunctionVariables = new HashSet<>();    //using a HashSet to get all unique variables used in the b_Function

        for (int i=0; i<b_Function.length(); i++){          //adding unique capital letters to Set
            char currChar = b_Function.charAt(i);

            if (currChar >= 'A' && currChar <= 'Z'){
                b_FunctionVariables.add(currChar);
            }
        }

        List<Character> variablesList = new ArrayList<Character>(); //list that will be used for shuffling to generate random

        for (char currChar : b_FunctionVariables){      //add all variables used into the list for shuffling
            variablesList.add(currChar);
        }

        String[] variableOrders = new String[b_FunctionVariables.size()];   //String[] holds the newly created orders = to the number of variables

        int orderCounter = 0;

        while (orderCounter != b_FunctionVariables.size()){       //shuffling of variables used to generate unique random orders
            String newOrder = "";
            Collections.shuffle(variablesList);
            boolean isDuplicate = false;

            for (char currChar : variablesList){
                newOrder = newOrder + currChar;
            }

            for (int i=0; i<orderCounter; i++){
                if (variableOrders[i].equals(newOrder)){
                    isDuplicate = true;
                }
            }

            if (isDuplicate == false){
                variableOrders[orderCounter] = newOrder;
                orderCounter++;
            }
        }

        ArrayList<BDD_Class> BDD_list = new ArrayList<BDD_Class>();

        int minimumNodes = (int)Math.pow(2, b_FunctionVariables.size()+1)-1;
        BDD_Class bestOrderBDD = null;

        System.out.println("DNF Formula: " + b_Function);
        //testing the created orders
        System.out.println("Testing orders:");

        for (int i=0; i<variableOrders.length; i++){        //tests unique orders by iteratively creating BDDs of that order
            BDD_Class tempBDD = new BDD_Class();
            tempBDD.BDD_create(b_Function, variableOrders[i]);
            BDD_list.add(tempBDD);
            if (minimumNodes > tempBDD.actualNumOfNodes){       //keeping track of the min nodes BDD
                minimumNodes = tempBDD.actualNumOfNodes;
                bestOrderBDD = tempBDD;
            }
        }
        System.out.println("Best order: " + bestOrderBDD.getHeadNode().nodeOrder + " " + minimumNodes + " out of " + bestOrderBDD.expectedNumOfNodes + " nodes.");
        return bestOrderBDD.getHeadNode();

    }

    public char BDD_use(BDD_Node currNode, String variableValues){

        if (variableValues.length() != this.numOfVariables){
            System.out.println("Incorrect length of the string representing variable values.");
            return '9';
        }

        if (currNode.node_bFunction.equals("1")){
            return '1';
        }
        if (currNode.node_bFunction.equals("0")){
            return '0';
        }

        char temp = variableValues.charAt(currNode.currCharacter - 'A');

        if (temp == '0'){
            return BDD_use(currNode.leftChild_0, variableValues);

        }
        else if (temp == '1'){
            return BDD_use(currNode.rightChild_1, variableValues);
        }
        else {      //case of incorrect parameter input (does not represent variables correctly:  0101 - ABCD)
            return '9';
        }
    }

    public BDD_Node getHeadNode(){
        return this.headNode;
    }

    public void setHeadNode(BDD_Node headNode){
        this.headNode = headNode;
    }

    public String solveLeftChild(char currCharacter, BDD_Node currNode){
        String replacedFormula = currNode.node_bFunction.replace(currCharacter, '0');
        replacedFormula = replacedFormula.replace("!0", "1");       //replacing negations

        String[] b_FunctionMembers = replacedFormula.split("\\+");


        for (int i = 0; i < b_FunctionMembers.length; i++) {

            if (b_FunctionMembers[i].equals("1")){           //if one of the members is a pure one, we can assume the result boolean is 1
                return "1";
            }

            if (b_FunctionMembers[i].contains("0")) {     //if the member contains 0, the whole member is 0
                b_FunctionMembers[i] = "";
            }

            if (b_FunctionMembers[i].contains("1")) {       //remove the 1 correctly depending on position
                if (b_FunctionMembers[i] == "1"){
                    continue;
                }
                if (b_FunctionMembers[i].charAt(0) == '1'){
                    b_FunctionMembers[i] = b_FunctionMembers[i].replace("1.", "");  //remove 1.
                } else if(b_FunctionMembers[i].charAt(b_FunctionMembers[i].length()-1) == '1'){
                    b_FunctionMembers[i] = b_FunctionMembers[i].replace(".1", "");  //remove .1
                } else{
                    b_FunctionMembers[i] = b_FunctionMembers[i].replace("1.", "");  //remove 1.
                }
            }
        }

        String leftChildFormula = "";

        for (int i = 0; i < b_FunctionMembers.length; i++) {
            if (b_FunctionMembers[i] == ""){
                continue;
            }else{
                if (leftChildFormula == ""){
                    leftChildFormula = b_FunctionMembers[i];
                } else {
                    leftChildFormula = leftChildFormula + "+" + b_FunctionMembers[i];
                }
            }
        }

        if (leftChildFormula.equals("")){  //in case the whole expression was nullified, we return 0
            return "0";
        }

        return leftChildFormula;
    }

    public String solveRightChild(char currCharacter, BDD_Node currNode){
        String replacedFormula = currNode.node_bFunction.replace(currCharacter, '1');

        replacedFormula = replacedFormula.replace("!1", "0"); //replacing negations

        String[] b_FunctionMembers = replacedFormula.split("\\+");

        //delete members containing 0 and removing 1 depending on position in member
        for (int i = 0; i < b_FunctionMembers.length; i++) {

            if (b_FunctionMembers[i].contains("0")) {
                b_FunctionMembers[i] = "";
            }

            if (b_FunctionMembers[i].equals("1")){           //if one of the members is a pure one, we can assume the result boolean is 1
                return "1";
            }

            if (b_FunctionMembers[i].contains("1")) {
                if (b_FunctionMembers[i] == "1"){
                    continue;
                }
                if (b_FunctionMembers[i].charAt(0) == '1'){
                    b_FunctionMembers[i] = b_FunctionMembers[i].replace("1.", "");  //remove 1.
                } else if(b_FunctionMembers[i].charAt(b_FunctionMembers[i].length()-1) == '1'){
                    b_FunctionMembers[i] = b_FunctionMembers[i].replace(".1", "");  //remove .1
                } else{
                    b_FunctionMembers[i] = b_FunctionMembers[i].replace("1.", "");  //remove .1.
                }
            }
        }

        String rightChildFormula = "";


        for (int i = 0; i < b_FunctionMembers.length; i++) {
            if (b_FunctionMembers[i] == ""){
                continue;
            }else{
                if (rightChildFormula == ""){
                    rightChildFormula = b_FunctionMembers[i];
                } else {
                    rightChildFormula = rightChildFormula + "+" + b_FunctionMembers[i];
                }
            }
        }

        if (rightChildFormula.equals("")){  //in case the whole expression was nullified, we
            return "0";
        }

        return rightChildFormula;
    }

    public void BDD_traversal(BDD_Node currNode){
        if (currNode == null){
            return;
        }
        System.out.println(currNode.node_bFunction);
        BDD_traversal(currNode.leftChild_0);
        BDD_traversal(currNode.rightChild_1);
    }

    public int getHash(String b_Function) {
        int hash = 0;
        int n = b_Function.length();
        for (int i = 0; i < n; i++) {
            hash = 31 * hash + b_Function.charAt(i);
        }
        return hash;
    }

    public void countActualNodes(BDD_Node currNode){
        countingAlgorithm(currNode);
        countingCleanAlgorithm(currNode);
    }

    public void countingAlgorithm(BDD_Node currNode){
        if (currNode == null){
            return;
        }

        if (currNode.isCounted == false){
            this.actualNumOfNodes++;
            currNode.isCounted = true;
        }

        countingAlgorithm(currNode.leftChild_0);
        countingAlgorithm(currNode.rightChild_1);
    }

    public void countingCleanAlgorithm(BDD_Node currNode){
        if (currNode == null){
            return;
        }

        if (currNode.isCounted == true){
            currNode.isCounted = false;
        }

        countingCleanAlgorithm(currNode.leftChild_0);
        countingCleanAlgorithm(currNode.rightChild_1);
    }
}
