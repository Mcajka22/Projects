package Main;

import Binary_Decision_Diagram.BDD_Class;
import RandomDNFGenerator.RandomDNF_Generator;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws IOException {

        /*
            Input formula needs to be in the DNF format, using the following operators
            . for and
            + for or
            ! for negation
            example formula:
            "!A.B.!C.D+A.!B.C.!D+A.B.!C.D+!A.!B.!C.D"

            The function calls are:
            BDD_Class.BDD_create("A.B.!C+!A.B.!C, ACB)
            BDD_Class.BDD_create_with_best_order(A.B.!C+!A.B.!C) // returns head of tree with most reducing order of variables
            BDD_Class.BDD_use(BDD_Node headNode, "0101")
        */

        while (true) {
            System.out.println("Select the number corresponding to the desired option.");
            System.out.println("1. BDD_create Test Case");
            System.out.println("2. BDD_create_with_best_order Test Case");
            System.out.println("3. BDD_use Test Case");
            System.out.println("4. BDD_use Whole Single Formula Test Case");
            System.out.println("5. Generate 100 complete strings");
            System.out.println("6. Generate 100 random length strings");
            System.out.println("Enter any other number to quit");

            System.out.print("Enter your choice: ");
            Scanner scanner = new Scanner(System.in);
            int choice = scanner.nextInt();
            System.out.println();

            switch (choice) {
                case 1:
                    testCaseBDD_Create();
                    break;
                case 2:
                    testCaseBDD_Create_With_Best_Order();
                    break;
                case 3:
                    testCaseBDD_Use();
                    break;
                case 4:
                    testCaseBDD_UseWhole_bFormula();
                    break;
                case 5:
                    generateNewCompleteStrings();
                    break;
                case 6:
                    generateNewRandomStrings();
                    break;
                default:
                    scanner.close();
                    return;
            }
        }
    }

    public static void testCaseBDD_Create() throws FileNotFoundException {

        File testFile = new File("CompleteTestFormulas.txt");
        Scanner newScanner = new Scanner(testFile);

        Scanner inputScanner = new Scanner(System.in);
        System.out.println("\nSet the order of variables for input into the formula in the format (ex. ABCDEF, CDEBAF)");
        String orderOfVariables = inputScanner.nextLine();
        System.out.println(orderOfVariables);

        long startTime = System.nanoTime();

        for (int i=0; i<100; i++){
            String testString = newScanner.nextLine();
            BDD_Class tempBDD = new BDD_Class();
            tempBDD.BDD_create(testString, orderOfVariables);
        }
        newScanner.close();

        long endTime = System.nanoTime();
        long duration = (endTime - startTime);  // time in nanoseconds
        double seconds = (double)duration / 1_000_000_000.0;  // conversion to seconds
        System.out.println("Time for this test: " + seconds + " seconds.");
    }

    public static void testCaseBDD_Create_With_Best_Order() throws FileNotFoundException {

        File testFile = new File("CompleteTestFormulas.txt");
        Scanner newScanner = new Scanner(testFile);

        long startTime = System.nanoTime();

        for (int i=0; i<100; i++){
            String testString = newScanner.nextLine();
            BDD_Class tempBDD = new BDD_Class();
            System.out.println(tempBDD.BDD_create_with_best_order(testString).node_bFunction);
        }
        newScanner.close();

        long endTime = System.nanoTime();
        long duration = (endTime - startTime);  // time in nanoseconds
        double seconds = (double)duration / 1_000_000_000.0;  // conversion to seconds
        System.out.println("Time for this test: " + seconds + " seconds.");
    }

    public static void testCaseBDD_Use() throws FileNotFoundException {

        File testFile = new File("CompleteTestFormulas.txt");
        Scanner newScanner = new Scanner(testFile);

        Scanner inputScanner = new Scanner(System.in);
        System.out.println("\nSet the order of variables for input into the formula in the format (ex. ABCDEF, CDEBAF)");
        String orderOfVariables = inputScanner.nextLine();
        System.out.println(orderOfVariables);

        System.out.println("\nSet the values of variables in the format (for A=0, B=1, C=0, D=1 - 0101)");
        String variableValues = inputScanner.nextLine();
        System.out.println(orderOfVariables);

        long startTime = System.nanoTime();

        int trueCounter = 0;

        for (int i=0; i<100; i++){
            String testString = newScanner.nextLine();
            BDD_Class tempBDD = new BDD_Class();
            tempBDD.BDD_create(testString, orderOfVariables);
            System.out.println();
            char BDD_useResult =  tempBDD.BDD_use(tempBDD.getHeadNode(), variableValues);
            char BDDcheckerResult = BDDuseChecker(tempBDD.getHeadNode().node_bFunction, variableValues);
            System.out.print("BDD_use result: " + BDD_useResult + ", BDD_Check result: " + BDDcheckerResult);
            if (BDD_useResult == BDDcheckerResult){
                System.out.println(" True");
                trueCounter++;
            }
            else{
                System.out.println(" False");
            }
        }
        System.out.println("True counter: " + trueCounter);
        newScanner.close();

        long endTime = System.nanoTime();
        long duration = (endTime - startTime);  // time in nanoseconds
        double seconds = (double)duration / 1_000_000_000.0;  // conversion to seconds
        System.out.println("Time for this test: " + seconds + " seconds.");
    }

    public static void testCaseBDD_UseWhole_bFormula(){

        Scanner newScanner = new Scanner(System.in);
        System.out.print("Enter the desired number of variables to be used: ");
        int numOfVariables = newScanner.nextInt();
        newScanner.nextLine();

        RandomDNF_Generator newGenerator = new RandomDNF_Generator(numOfVariables);
        String testString = newGenerator.generateCompleteString();
        System.out.println("Testing DNF Formula: " + testString);

        System.out.println("\nSet the order of variables for input into the formula in the format (ex. ABCDEF, CDEBAF)");
        String orderOfVariables = newScanner.nextLine();
        System.out.println(orderOfVariables);

        BDD_Class tempBDD = new BDD_Class();
        tempBDD.BDD_create(testString, orderOfVariables);    //BDD instance creation for BDD_Use checking

        int numOfPermutations = (int) Math.pow(2, numOfVariables);
        for (int i = 0; i < numOfPermutations; i++) {
            
            String binary = Integer.toBinaryString(i);
            binary = "0".repeat(numOfVariables - binary.length()) + binary;

            char BDD_useResult = tempBDD.BDD_use(tempBDD.getHeadNode(), binary);
            char BDD_useCheckerResult = BDDuseChecker(testString, binary);

            System.out.println("Variable values (A-n): " + binary);
            if (BDD_useResult == BDD_useCheckerResult) System.out.println("True");
            else System.out.println("False");
            System.out.println("BDD_use result: " + BDD_useResult + ", BDD_useChecker result: " + BDD_useCheckerResult + "\n");
        }
    }

    public static void generateNewCompleteStrings() throws IOException {
        FileWriter writeToFile = new FileWriter("CompleteTestFormulas.txt");
        Scanner newScanner = new Scanner(System.in);
        System.out.print("Enter the desired number of variables to be used: ");
        int numOfVariables = newScanner.nextInt();

        RandomDNF_Generator newGenerator = new RandomDNF_Generator(numOfVariables);

        String testString;

        for (int i=0; i<100; i++){
            testString = newGenerator.generateCompleteString();
            writeToFile.write(testString);       //adding the newString to the file
            writeToFile.write("\n");            //and adding a newLine
            System.out.println(testString);
        }
        writeToFile.close();
    }

    public static void generateNewRandomStrings() throws IOException {
        FileWriter writeToFile = new FileWriter("RandomTestFormulas.txt");
        Scanner newScanner = new Scanner(System.in);
        System.out.print("Enter the desired number of variables to be used: ");
        int numOfVariables = newScanner.nextInt();

        RandomDNF_Generator newGenerator = new RandomDNF_Generator(numOfVariables);

        String testString;

        for (int i=0; i<100; i++){
            testString = newGenerator.generateRandomString();
            writeToFile.write(testString);       //adding the newString to the file
            writeToFile.write("\n");            //and adding a newLine
            System.out.println(testString);
        }
        writeToFile.close();
    }

    public static char BDDuseChecker(String b_Formula, String variableValues){
        String replacedFormula = "";

        for (int i=0; i<b_Formula.length(); i++){
            char currChar = b_Formula.charAt(i);

            if (currChar>= 'A' && currChar <= 'Z'){
                replacedFormula = replacedFormula + variableValues.charAt(currChar-'A'); //append the 0 or 1 from the index of the variable ASCII - A ASCII
            }
            else{
                replacedFormula = replacedFormula + currChar;   //else append current character
            }
        }
        replacedFormula = replacedFormula.replace("!0", "1");
        replacedFormula = replacedFormula.replace("!1", "0");

        String[] b_FunctionMembers = replacedFormula.split("\\+");

        for (String member : b_FunctionMembers){
            for (int i=0; i<member.length(); i++) {
                char currChar = member.charAt(i);           //if a 0 is found in the member, we break at the iteration as that member cannot be 1
                if (currChar == '0'){
                    break;
                }
                if (i == member.length()-1){        //reached the end of the member without finding 0, return 1
                    return '1';
                }
            }
        }
        return '0';         // found a 0 in each member, return 0
    }
}
