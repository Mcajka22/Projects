package SepChaing_HashTable;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class SepChaining_HashTable {

    private static final int startingCapacity = 50;
    private static final double resizeFactor = .80;
    private int numOfElements = 0;
    private int currCapacity;
    private SepChaining_Node[] hashTable;

    public SepChaining_HashTable(){
        this.currCapacity = this.startingCapacity;
        this.hashTable = new SepChaining_Node[currCapacity];
    }
    
    public int deleteSepChaining_HashTable(String targetData){

        int targetHash = calcHashValue(targetData);

        if (this.numOfElements == 0 || this.hashTable[targetHash] == null){     // in case the element counter is 0 or the index is empty the value does not exist
            return -1;
        }

        this.numOfElements--;
        if (this.currCapacity > 50 && (float)this.numOfElements/(float)this.currCapacity < 1 - this.resizeFactor){
            this.hashTable = resizeNegative(this.hashTable);
            targetHash = calcHashValue(targetData);   //recalculating the value in case the table was resized
        }

        SepChaining_Node tempNode = this.hashTable[targetHash];      //get index node
        if (tempNode.data.equals(targetData)){
            if (tempNode.next == null){                 //if the data is at index node, and it does not have any nodes chained
                this.hashTable[targetHash] = null;         //index is set to null

            } else {                //else the index node is deleted by being replaced with the next node
                this.hashTable[targetHash] = tempNode.next;
            }
            return 0;
        } else {        //else it is searched for in the chained nodes
            while (tempNode.next != null){
                if (tempNode.next.data.equals(targetData)){
                    tempNode.next = tempNode.next.next;
                    return 0;
                }
                tempNode = tempNode.next;
            }
        }       //if it was not found it does not exist in the table
        System.out.println("The table does not contain that data. Nothing to delete.");
        this.numOfElements++;       //increment as nothing was deleted
        return -1;
    }

    public SepChaining_Node[] resizeNegative(SepChaining_Node[] oldHashTable){
        this.currCapacity /= 2;      //the new table capacity doubles when resize condition is met
        System.out.println("Resizing negatively, new capacity is " + this.currCapacity + " elements.");

        SepChaining_Node[] newHashTable = new SepChaining_Node[this.currCapacity];

        for (int i=0; i<(this.currCapacity*2); i++){            //remaping the old hash table to the new one
            if (oldHashTable[i] != null){
                while (oldHashTable[i] != null){                //while nodes still exist at current index
                    SepChaining_Node tempNode = oldHashTable[i];
                    SepChaining_Node nextNode = tempNode.next;
                    tempNode.hashValue = calcHashValue(tempNode.data);      //we update hash of each node for new table
                    tempNode.next = null;                                   //and remove the linked elements

                    if (newHashTable[tempNode.hashValue] == null){           //and fit it into table at index if emptyy
                        newHashTable[tempNode.hashValue] = tempNode;
                    } else {                                                 //else we chain it to the last node
                        SepChaining_Node tempNodeNewTable = newHashTable[tempNode.hashValue];
                        while (tempNodeNewTable.next != null){
                            tempNodeNewTable = tempNodeNewTable.next;
                        }
                        tempNodeNewTable.next = tempNode;
                    }
                    oldHashTable[i] = nextNode;             //after updating each node in new table we delete it from the old table
                }
            }
        }
        return newHashTable;        //returning the new table
    }

    
    public SepChaining_Node searchSepChaining_HashTable(String targetData){
        int targetHash = calcHashValue(targetData);

        if (this.hashTable[targetHash] == null){                //if hash result index is null, target data does not exist in the table
            System.out.println("Value not found in the table!");
            return null;
        }

        SepChaining_Node tempNode = this.hashTable[targetHash];     //here the element is copied
        if (tempNode.data.equals(targetData)){                     //if it is the target
            return tempNode;
        } else{
            while(tempNode.next != null){                       //else we loop while we the next chain isnt null
                if (tempNode.next.data.equals(targetData)){        //found
                    return tempNode.next;
                }
                tempNode = tempNode.next;
            }
        }       //element wasn't found
        System.out.println("Value not found in the table!");
        return null;
    }

    public void insertSepChaining_HashTable(String newData){

        this.numOfElements++;

        if ((float)this.numOfElements/(float)this.currCapacity > this.resizeFactor){        //resize if load > .80
            this.hashTable = resizePositive(this.hashTable);
        }

        SepChaining_Node newNode = new SepChaining_Node(newData);
        newNode.hashValue = calcHashValue(newData);

        if (hashTable[newNode.hashValue] == null){      //if given index is empty we just assign new node
            hashTable[newNode.hashValue] = newNode;
        } else{                     //else we cycle though nodes at index and add node at the end
            SepChaining_Node tempNode = hashTable[newNode.hashValue];

            while (tempNode.next != null){
                    if (tempNode.data.equals(newNode.data)){
                        System.out.println("This value already exists in the tree.");
                        this.numOfElements--;
                        return;
                    }
                    tempNode = tempNode.next;
            }
            tempNode.next = newNode; //adding new node
        }
    }

    public SepChaining_Node[] resizePositive(SepChaining_Node[] oldHashTable){
        this.currCapacity *= 2;      //the new table capacity doubles when resize condition is met

        System.out.println("Resizing positively, new capacity is " + this.currCapacity + " elements.");
        SepChaining_Node[] newHashTable = new SepChaining_Node[this.currCapacity];

        for (int i=0; i<(this.currCapacity/2); i++){            //re-maping the old hash table to the new one
            if (oldHashTable[i] != null){
                while (oldHashTable[i] != null){                //while nodes still exist at current index
                    SepChaining_Node tempNode = oldHashTable[i];
                    SepChaining_Node nextNode = tempNode.next;
                    tempNode.hashValue = calcHashValue(tempNode.data);      //we update hash of each node for new table
                    tempNode.next = null;                                   //and remove the linked elements

                    if (newHashTable[tempNode.hashValue] == null){           //and fit it into table at index if emptyy
                        newHashTable[tempNode.hashValue] = tempNode;
                    } else {                                                 //else we chain it to the last node
                        SepChaining_Node tempNodeNewTable = newHashTable[tempNode.hashValue];
                        while (tempNodeNewTable.next != null){
                            tempNodeNewTable = tempNodeNewTable.next;
                        }
                        tempNodeNewTable.next = tempNode;
                    }
                    oldHashTable[i] = nextNode;             //after updating each node in new table we delete it from the old table
                }
            }
        }
        return newHashTable;        //returning the new table
    }

    public int calcHashValue(String data){      //calculates the hash value for given data string as the sum of characters of string + 22 modulo the size of table
        int hashResult = 0;

        for (int i=0; i<data.length(); i++){
            hashResult = hashResult * 7 + data.charAt(i);
        }
        return Math.abs(hashResult) % this.currCapacity;
    }

    public void printHashTable(){       //prints the hash table and chained nodes to given indexes
        for (int i=0; i < this.currCapacity; i++){
            if (this.hashTable[i] == null){
                System.out.println(i + " ---");
            } else{
                System.out.print(i + " " + this.hashTable[i].data);
                SepChaining_Node tempNode = this.hashTable[i];

                while (tempNode.next != null){
                    System.out.print(" -> " + tempNode.next.data);
                    tempNode = tempNode.next;
                }
                System.out.println();
            }
        }
    }

    public static void main(String[] args) throws FileNotFoundException {

        File testFile = new File("testData_1M.txt");
        Scanner scannerInsert = new Scanner(testFile);
        Scanner scannerSearch = new Scanner(testFile);
        Scanner scannerDelete = new Scanner(testFile);

        SepChaining_HashTable HashTable = new SepChaining_HashTable();

        for (int i = 0; i < 50; i++){
            String newDataString = scannerInsert.nextLine();
            HashTable.insertSepChaining_HashTable(newDataString);
        }
        for (int i = 0; i < 50; i++){
            String newDataString = scannerSearch.nextLine();
            HashTable.searchSepChaining_HashTable(newDataString);
        }
        for (int i = 0; i < 40; i++){
            String newDataString = scannerDelete.nextLine();
            HashTable.deleteSepChaining_HashTable(newDataString);
        }
        HashTable.searchSepChaining_HashTable("One");
        HashTable.deleteSepChaining_HashTable("One");

        HashTable.printHashTable();
        scannerInsert.close();
        scannerSearch.close();
        scannerDelete.close();
    }

}
