package SepChaing_HashTable;

public class SepChaining_Node {
    int hashValue;
    String data;
    SepChaining_Node next;

    public SepChaining_Node(String newData){
        this.data = newData;
    }
}
