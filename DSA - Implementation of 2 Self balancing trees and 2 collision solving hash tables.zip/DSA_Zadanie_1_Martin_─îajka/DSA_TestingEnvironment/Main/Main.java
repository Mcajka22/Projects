package Main;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;

import AVL_Tree.*;
import RedBlack_Tree.*;
import SepChaing_HashTable.*;
import LinProbing_HashTable.*;

public class Main {

    public static void AVL_TreeTesting() throws FileNotFoundException {

        File testFile = new File("testData_1M.txt");
        Scanner scannerInsert = new Scanner(testFile);
        Scanner scannerSearch = new Scanner(testFile);
        Scanner scannerDelete = new Scanner(testFile);

        AVL_Tree AVL_Tree = new AVL_Tree();

        long startTime = System.nanoTime();

        for (int i = 0; i < 750000; i++){
            String newDataString = scannerInsert.nextLine();
            AVL_Tree.rootNode = AVL_Tree.insertNodeAVL(AVL_Tree.rootNode, newDataString);
        }
        for (int i = 0; i < 750000; i++){
            String newDataString = scannerSearch.nextLine();
            AVL_Tree.searchNodeAVL(AVL_Tree.rootNode, newDataString);
        }
        for (int i = 0; i < 750000; i++){
            String newDataString = scannerDelete.nextLine();
            AVL_Tree.rootNode = AVL_Tree.deleteNodeAVL(AVL_Tree.rootNode, newDataString);
        }

        //AVL_Tree.preOrderTraversal(AVL_Tree.rootNode);
        scannerInsert.close();
        scannerSearch.close();
        scannerDelete.close();

        long endTime = System.nanoTime();
        long duration = (endTime - startTime);  // time in nanoseconds
        double seconds = (double)duration / 1_000_000_000.0;  // conversion to seconds
        System.out.println("Time for this test: " + seconds + " seconds.");
    }

    public static void RedBlack_TreeTesting() throws FileNotFoundException {

        File testFile = new File("testData_1M.txt");
        Scanner scannerInsert = new Scanner(testFile);
        Scanner scannerSearch = new Scanner(testFile);
        Scanner scannerDelete = new Scanner(testFile);

        RedBlack_Tree RedBlackTree = new RedBlack_Tree();

        long startTime = System.nanoTime();

        for (int i = 0; i < 750000; i++){
            String newDataString = scannerInsert.nextLine();
            RedBlackTree.insertNodeRedBlack(newDataString);
        }
        for (int i = 0; i < 750000; i++){
            String newDataString = scannerSearch.nextLine();
            RedBlackTree.searchNodeRedBlack(RedBlackTree.rootNode, newDataString);
        }
        for (int i = 0; i < 750000; i++){
            String newDataString = scannerDelete.nextLine();
            RedBlackTree.deleteNodeRedBlack(RedBlackTree.rootNode, newDataString);
        }

        //RedBlackTree.preOrderTraversal(RedBlackTree.rootNode);
        scannerInsert.close();
        scannerSearch.close();
        scannerDelete.close();

        long endTime = System.nanoTime();
        long duration = (endTime - startTime);  // time in nanoseconds
        double seconds = (double)duration / 1_000_000_000.0;  // conversion to seconds
        System.out.println("Time for this test: " + seconds + " seconds.");
    }

    public static void LinearProbing_Testing() throws FileNotFoundException {
        File testFile = new File("testData_1M.txt");
        Scanner scannerInsert = new Scanner(testFile);
        Scanner scannerSearch = new Scanner(testFile);
        Scanner scannerDelete = new Scanner(testFile);
        LinearProbing_HashTable HashTable = new LinearProbing_HashTable();

        long startTime = System.nanoTime();

        for (int i = 0; i < 750000; i++){
            String newDataString = scannerInsert.nextLine();
            HashTable.insertLinearProbing_HashTable(newDataString);}
        for (int i = 0; i < 750000; i++){
            String newDataString = scannerSearch.nextLine();
            HashTable.searchLinearProbing_HashTable(newDataString);}
        for (int i = 0; i < 750000; i++){
            String newDataString = scannerDelete.nextLine();
            HashTable.deleteLinearProbing_HashTable(newDataString);}

        scannerInsert.close();
        scannerSearch.close();
        scannerDelete.close();

        long endTime = System.nanoTime();
        long duration = (endTime - startTime);  // time in nanoseconds
        double seconds = (double)duration / 1_000_000_000.0;  // conversion to seconds
        System.out.println("Time for this test: " + seconds + " seconds.");
    }

    public static void SepChaining_Testing() throws FileNotFoundException {

        File testFile = new File("testData_1M.txt");
        Scanner scannerInsert = new Scanner(testFile);
        Scanner scannerSearch = new Scanner(testFile);
        Scanner scannerDelete = new Scanner(testFile);

        SepChaining_HashTable HashTable = new SepChaining_HashTable();

        long startTime = System.nanoTime();

        for (int i = 0; i < 750000; i++){
            String newDataString = scannerInsert.nextLine();
            HashTable.insertSepChaining_HashTable(newDataString);
        }
        for (int i = 0; i < 750000; i++){
            String newDataString = scannerSearch.nextLine();
            HashTable.searchSepChaining_HashTable(newDataString);
        }
        for (int i = 0; i < 750000; i++){
            String newDataString = scannerDelete.nextLine();
            HashTable.deleteSepChaining_HashTable(newDataString);
        }

        //HashTable.printHashTable();
        scannerInsert.close();
        scannerSearch.close();
        scannerDelete.close();

        long endTime = System.nanoTime();
        long duration = (endTime - startTime);  // time in nanoseconds
        double seconds = (double)duration / 1_000_000_000.0;  // conversion to seconds
        System.out.println("Time for this test: " + seconds + " seconds.");
    }

    public static void main(String[] args) throws IOException {
        System.out.println("Welcome to the DSA Assignment 1 tester.");

        while (true){
            System.out.println("Select number corresponding to the algorithm.");
            System.out.println("1. AVL Tree");
            System.out.println("2. Red Black Tree");
            System.out.println("3. Hash Table Linear Probing");
            System.out.println("4. Hash Table Separate Chaining");
            System.out.println("5. Generate Strings");
            System.out.println("Enter any other number to quit");

            System.out.print("Enter your choice: ");
            Scanner scanner = new Scanner(System.in);
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    AVL_TreeTesting();
                    break;
                case 2:
                    RedBlack_TreeTesting();
                    break;
                case 3:
                    LinearProbing_Testing();
                    break;
                case 4:
                    SepChaining_Testing();
                    break;
                case 5:
                    RandomStringGenerator stringGen = new RandomStringGenerator();
                    stringGen.generateStrings();
                default:
                    return;
            }
        }
    }
}

