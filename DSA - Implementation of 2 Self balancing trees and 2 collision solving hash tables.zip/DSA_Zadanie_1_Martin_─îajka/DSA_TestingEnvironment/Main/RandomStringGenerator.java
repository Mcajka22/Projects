package Main;

import java.io.FileWriter;
import java.io.IOException;
import java.util.Random;

public class RandomStringGenerator {
    private static final String ALLOWED_CHARS = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    private static final Random RANDOM = new Random();
    private static final int MIN_LENGTH = 6;
    private static final int MAX_LENGTH = 12;
    private static final int NUMBER_OF_STRINGS = 1000000;

    public static void generateStrings() throws IOException {
        FileWriter writeToFile = new FileWriter("testData_1M.txt");
        for (int i = 1; i <= NUMBER_OF_STRINGS; i ++){
            String newString = "";
            int newStringLength = RANDOM.nextInt(MIN_LENGTH, MAX_LENGTH+1);    //setting random sting length from interval
            System.out.println(i + " " + newStringLength);

            for (int k = 1; k <= newStringLength; k ++){        //adding characters in iteration
                newString = newString + ALLOWED_CHARS.charAt(RANDOM.nextInt(ALLOWED_CHARS.length()));
            }
            writeToFile.write(newString);       //adding the newString to the file
            writeToFile.write("\n");            //and adding a newLine
            System.out.println(newString);

        }
        writeToFile.close();
    }
}
