package RedBlack_Tree;

public class RedBlack_Tree {
    public RedBlack_Node rootNode;

    public RedBlack_Tree(){
        this.rootNode = null;
    }
    public RedBlack_Node deleteNodeRedBlack(RedBlack_Node currNode, String targetData){
        if (currNode == null){  //not found in tree
            return null;
        }

        int compareResult = targetData.compareTo(currNode.data);      //string comparison (alphabetic) result

        if (compareResult < 0){
            deleteNodeRedBlack(currNode.leftChild, targetData);
        } else if(compareResult > 0){
            deleteNodeRedBlack(currNode.rightChild, targetData);
        } else{ // we found the node
            RedBlack_Node childNode, parentNode;
            if (currNode.leftChild == null && currNode.rightChild == null){ //case deleted node does not have any child
                parentNode = currNode.parent;

                if (parentNode == null){ //in case the deleted node is the root, it is the only element in the tree, and we delete it
                    this.rootNode = null;
                } else{
                    if (currNode == parentNode.leftChild){  //else we remove the parents pointer currNode
                        parentNode.leftChild = null;
                    } else {
                        parentNode.rightChild = null;
                    }
                    checkRulesDelete(currNode);     //check if the tree needs fixing

                }
            } else if (currNode.leftChild == null || currNode.rightChild == null) { //else if the deleted node has one child
                parentNode = currNode.parent;
                childNode = (currNode.leftChild != null) ? currNode.leftChild : currNode.rightChild;  //find and set child

                if (childNode != null){    //child node should never be null, but leaving it in just in case
                    childNode.parent = parentNode;
                }

                if (parentNode == null){            //deleted node was root
                    this.rootNode = childNode;
                } else {
                    if (currNode == parentNode.leftChild){    //else we just replace deleted nodes position with child
                        parentNode.leftChild = childNode;
                    } else{
                        parentNode.rightChild = childNode;
                    }
                    checkRulesDelete(currNode);   //check if the tree needs fixing

                }
            } else{         //case the tree has both children
                RedBlack_Node rightSubtreeMinNode = findSubtreeMin(currNode.rightChild);      //we find the min value node in the right subtree
                currNode.data = rightSubtreeMinNode.data;               //replace node to be deleted
                currNode = deleteNodeRedBlack(currNode.rightChild, rightSubtreeMinNode.data); //and deleted node that replaced curr node
            }
        }
        return currNode;
    }

    public void checkRulesDelete(RedBlack_Node currNode){
        RedBlack_Node siblingNode;

        while (currNode.isBlack && currNode != this.rootNode){

            if (currNode.data.compareTo(currNode.parent.data) < 0){             //if node is left child
                siblingNode = currNode.parent.rightChild;         //sibling is right child of parent

                if (siblingNode != null && siblingNode.isBlack == false){                              //if sibling is red
                    siblingNode.isBlack = true;
                    currNode.isBlack = false;
                    leftRotation(currNode.parent);
                    siblingNode = currNode.parent.rightChild;
                }
                if (siblingNode == null){return;}

                if (siblingNode.leftChild == null && siblingNode.rightChild == null){ //in case both child nodes are null (black)
                    siblingNode.isBlack = false;
                    currNode = currNode.parent;
                } else {
                    if (siblingNode.rightChild == null){  //else if siblings right child is black or null - right rotation recolor
                        siblingNode.leftChild.isBlack = true;
                        siblingNode.isBlack = false;
                        rightRotation(siblingNode);
                        siblingNode = currNode.parent.rightChild;
                    }
                    siblingNode.isBlack = currNode.parent.isBlack;    //left rotation recolor
                    currNode.parent.isBlack = true;
                    siblingNode.rightChild.isBlack = true;
                    leftRotation(currNode.parent);
                    currNode = this.rootNode;
                }
            } else {    //if deleted node is right child - same algorithm just reversed sides
                siblingNode = currNode.parent.leftChild;

                if (siblingNode != null && siblingNode.isBlack == false){
                    siblingNode.isBlack = true;
                    currNode.parent.isBlack = false;
                    rightRotation(currNode.parent);
                    siblingNode = currNode.parent.leftChild;
                }

                if (siblingNode == null){return;}

                if (siblingNode.leftChild == null && siblingNode.rightChild == null){
                    siblingNode.isBlack = false;
                    currNode = currNode.parent;

                } else {
                    if (siblingNode.leftChild == null){
                        siblingNode.rightChild.isBlack = true;
                        siblingNode.isBlack = false;
                        leftRotation(siblingNode);
                        siblingNode = currNode.parent.leftChild;
                    }
                    siblingNode.isBlack = currNode.parent.isBlack;
                    currNode.parent.isBlack = true;
                    siblingNode.leftChild.isBlack = true;
                    rightRotation(currNode.parent);
                    currNode = this.rootNode;
                }
            }
        }
        currNode.isBlack = true;
    }

    public RedBlack_Node findSubtreeMin(RedBlack_Node currNode){    //finds the lowest value in the subtree
        if (currNode == null || currNode.leftChild == null){
            return currNode;
        }
        return findSubtreeMin(currNode.leftChild);
    }

    public void insertNodeRedBlack(String newData){       //function that helps recursively insert node and calls a check after the node is inserted
        RedBlack_Node newNode = new RedBlack_Node(newData);
        this.rootNode = insertAlgo(this.rootNode, newNode); //recursive function that inserts the new node, checks (and fixes) rule violations
        checkRules(newNode);
        this.rootNode.isBlack = true;   //updates root to black after insertion
    }

    public RedBlack_Node insertAlgo(RedBlack_Node currNode, RedBlack_Node newNode){
        if (currNode == null){     //new node is inserted with return recursively
            return newNode;
        }

        int compareResult = newNode.data.compareTo(currNode.data);      //string comparison (alphabetic) result

        if (compareResult < 0){         //recursive left child search
            currNode.leftChild = insertAlgo(currNode.leftChild, newNode);
            currNode.leftChild.parent = currNode;
        } else if (compareResult > 0){    //recursive right child search
            currNode.rightChild = insertAlgo(currNode.rightChild, newNode);
            currNode.rightChild.parent = currNode;
        } else{                 //value already exists
            return currNode;
        }
         //checks if there are not two following red nodes when recursion returns

        if (newNode == currNode){
            currNode.isBlack = false; //in case the node was changed during insertion algorithm, its color is returned to red
        }
        return currNode;
    }

    public void checkRules(RedBlack_Node newNode){  //function that checks if rules are met after insert and if not, fixes the tree and coloring

        while (newNode.parent != null && newNode.parent.isBlack == false && newNode.isBlack == false){  //in case the parent of a nod exists, and it is red as the node itself, the tree needs fixing

            RedBlack_Node nodeParent = newNode.parent;            //seting help variables
            RedBlack_Node nodeGrandparent = nodeParent.parent;
            RedBlack_Node nodeUncle;


            if (nodeParent == nodeGrandparent.leftChild) {      //if parent is the left child
                nodeUncle = nodeGrandparent.rightChild;             //uncle is the right child
                if (nodeUncle != null && nodeUncle.isBlack == false) {      //in case the uncle is red, the siblings become black and their parent red
                    nodeParent.isBlack = true;
                    nodeUncle.isBlack = true;
                    nodeGrandparent.isBlack = false;
                    newNode = nodeGrandparent;
                } else {
                    if (newNode == nodeParent.rightChild) {     //if the node is the right child, we do a left rotation before
                        newNode = nodeParent;
                        leftRotation(newNode);
                    }
                    newNode.parent.isBlack = true;      //recoloring before the rotation for the rotation results
                    nodeGrandparent.isBlack = false;
                    rightRotation(nodeGrandparent);
                }
            } else {                                   // if parent is right child
                nodeUncle = nodeGrandparent.leftChild;
                if (nodeUncle != null && nodeUncle.isBlack == false) {  //if uncle exists and is red
                    nodeParent.isBlack = true;
                    nodeUncle.isBlack = true;
                    nodeGrandparent.isBlack = false;
                    newNode = nodeGrandparent;
                } else {
                    if (newNode == nodeParent.leftChild) {  //if newNode is the left child we assign the parent to new node and do a right rotation
                        newNode = nodeParent;
                        rightRotation(newNode);
                    }
                    newNode.parent.isBlack = true;      //finish off with recoloring and right rotation
                    nodeGrandparent.isBlack = false;
                    leftRotation(nodeGrandparent);
                }
            }
        }
    }

    public void leftRotation(RedBlack_Node unbalancedNode){      //left rotation function
        RedBlack_Node nodeRightChild = unbalancedNode.rightChild;

        unbalancedNode.rightChild = nodeRightChild.leftChild; //right childs left child becomes nodes right child

        if (nodeRightChild.leftChild != null){      //in case it was not null we assign the unbalance node as its parent
            nodeRightChild.leftChild.parent = unbalancedNode;
        }

        nodeRightChild.parent = unbalancedNode.parent; //gp of right child is assigned as its parent

        if (unbalancedNode.parent == null){  //in case the unbalanced node was the root node, the right child becomes the root
            this.rootNode = nodeRightChild;
            //else it replaces the child position of unbalanced node
        } else if (unbalancedNode == unbalancedNode.parent.rightChild) {
            unbalancedNode.parent.rightChild = nodeRightChild;
        } else {
            unbalancedNode.parent.leftChild = nodeRightChild;
        }

        nodeRightChild.leftChild = unbalancedNode;      //unbalanced node becomes left child of its right child
        unbalancedNode.parent = nodeRightChild;         //we update the right child as the parent
    }

    public void rightRotation(RedBlack_Node unbalancedNode){      //right rotation function same algorithm just reversed as in left rotation
        RedBlack_Node nodeLeftChild = unbalancedNode.leftChild;

        unbalancedNode.leftChild = nodeLeftChild.rightChild;

        if (nodeLeftChild.rightChild != null){
            nodeLeftChild.rightChild.parent = unbalancedNode;
        }

        nodeLeftChild.parent = unbalancedNode.parent;

        if (unbalancedNode.parent == null){
            this.rootNode = nodeLeftChild;
            //else it replaces the child position of unbalanced node
        } else if (unbalancedNode == unbalancedNode.parent.leftChild) {
            unbalancedNode.parent.leftChild = nodeLeftChild;
        } else {
            unbalancedNode.parent.rightChild = nodeLeftChild;
        }

        nodeLeftChild.rightChild = unbalancedNode;
        unbalancedNode.parent = nodeLeftChild;
    }

    public void preOrderTraversal(RedBlack_Node currNode){

        if (currNode == null){
            return;
        }
        if (currNode.parent == null){
            System.out.println(currNode.data + " " + currNode.isBlack);
        }
        else if (currNode == currNode.parent.leftChild){
            System.out.println(currNode.data + " " + currNode.isBlack + " left child");
        }
        else {
            System.out.println(currNode.data + " " + currNode.isBlack + " right child");
        }
        preOrderTraversal(currNode.leftChild);
        preOrderTraversal(currNode.rightChild);
    }

    public RedBlack_Node searchNodeRedBlack(RedBlack_Node rootNode, String targetData){  //recursive search function to find value in tree
        if (rootNode == null){
            System.out.println("Value does not exist in the tree!");
            return null;
        }
        int compareResult = targetData.compareTo(rootNode.data);

        if (compareResult == 0){
            return rootNode;
        } else if (compareResult < 0){
            searchNodeRedBlack(rootNode.leftChild, targetData);
        } else{
            searchNodeRedBlack(rootNode.rightChild, targetData);
        }
        return null;
    }

    public static void main(String[] args){
        RedBlack_Tree Tree = new RedBlack_Tree();
        Tree.insertNodeRedBlack("One");
        Tree.insertNodeRedBlack("Two");
        Tree.insertNodeRedBlack("Three");
        Tree.insertNodeRedBlack("Four");
        Tree.insertNodeRedBlack("Five");
        Tree.insertNodeRedBlack("Six");
        Tree.insertNodeRedBlack("Seven");

        Tree.deleteNodeRedBlack(Tree.rootNode,"One");
        Tree.deleteNodeRedBlack(Tree.rootNode,"Three");
        /*Tree.deleteNodeRedBlack(Tree.rootNode,"Three");
        Tree.deleteNodeRedBlack(Tree.rootNode,"Four");
        Tree.deleteNodeRedBlack(Tree.rootNode,"Five");
        Tree.deleteNodeRedBlack(Tree.rootNode,"Six");
        Tree.deleteNodeRedBlack(Tree.rootNode,"Seven");
        Tree.deleteNodeRedBlack(Tree.rootNode,"Eight");*/

        Tree.preOrderTraversal(Tree.rootNode);
    }
}
