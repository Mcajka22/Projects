package RedBlack_Tree;

public class RedBlack_Node {
    boolean isBlack;
    String data;
    RedBlack_Node leftChild;
    RedBlack_Node rightChild;
    RedBlack_Node parent;

    public RedBlack_Node(String data){  //nodes are initialized with their data value and color, which should always be red
        this.data = data;
        this.isBlack = false;
        this.leftChild = null;
        this.rightChild = null;
        this.parent = null;
    }
}
