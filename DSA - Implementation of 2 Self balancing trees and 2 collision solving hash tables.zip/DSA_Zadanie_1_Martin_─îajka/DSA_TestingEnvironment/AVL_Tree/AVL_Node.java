package AVL_Tree;

public class AVL_Node { //an AVL node able to carry data, hold its height for balance and a reference to left and right child

    String data;
    int height;
    AVL_Node leftChild;
    AVL_Node rightChild;

    public AVL_Node(String data){  //nodes are initialized with their data value
        this.data = data;
        this.height = 1;          //default 1 as it is added as leafs/root at init
        this.leftChild = null;
        this.rightChild = null;
    }
}
