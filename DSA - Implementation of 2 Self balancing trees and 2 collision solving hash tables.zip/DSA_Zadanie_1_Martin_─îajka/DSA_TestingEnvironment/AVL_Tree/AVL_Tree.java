package AVL_Tree;

import java.io.IOException;

import static java.lang.Math.max;

public class AVL_Tree {

    public AVL_Node rootNode = null;

    public AVL_Node searchNodeAVL(AVL_Node rootNode, String targetData){     //recursive search function to find node
        if (rootNode == null){
            System.out.println("Value does not exist in the tree!");
            return null;
        }
        if (rootNode.data.equals(targetData)){
            return rootNode;
        } else if (targetData.compareTo(rootNode.data) < 0){
            searchNodeAVL(rootNode.leftChild, targetData);
        } else{
            searchNodeAVL(rootNode.rightChild, targetData);
        }
        return null;
    }

    public AVL_Node deleteNodeAVL(AVL_Node rootNode, String targetData){

        if (rootNode == null){
            return null;
        }

        int compareResult = targetData.compareTo(rootNode.data);

        if(compareResult < 0){
            rootNode.leftChild = deleteNodeAVL(rootNode.leftChild, targetData);
        } else if(compareResult > 0){
            rootNode.rightChild = deleteNodeAVL(rootNode.rightChild, targetData);
        } else{                                 //value has been found
            if (rootNode.leftChild == null){    //no left child - remember right child and return as child after deleting the target node
                AVL_Node tempNode = rootNode.rightChild;
                rootNode = null;
                return tempNode;
            } else if (rootNode.rightChild == null) { //same scenario other child node does not exist
                AVL_Node tempNode = rootNode.leftChild;
                rootNode = null;
                return tempNode;
            }   //if target node has both children we get here
            AVL_Node tempNode = findSubtreeMin(rootNode.rightChild);  //we find the min value in right child subtree
            rootNode.data = tempNode.data;  //we replace value of targetNode with right subtree min
            rootNode.rightChild = deleteNodeAVL(rootNode.rightChild, tempNode.data); //and search for former min node to delete
        }

        rootNode.height = 1 + max(getHeight(rootNode.leftChild),getHeight(rootNode.rightChild)); //update height
        int rootNodeBalance = calculateBalance(rootNode);

        //check to see if tree is balanced after deletion and balancing if not
        if (rootNodeBalance > 1 && calculateBalance(rootNode.leftChild) >=0 ){ // LL disbalance case
            return rightRotation(rootNode);
        }
        if (rootNodeBalance > 1 && calculateBalance(rootNode.leftChild) < 0){ // LR disbalance case
            rootNode.leftChild = leftRotation(rootNode.leftChild);
            return rightRotation(rootNode);
        }
        if (rootNodeBalance < -1 && calculateBalance(rootNode.rightChild) <= 0){ // RR disbalance case
            return leftRotation(rootNode);
        }
        if (rootNodeBalance < -1 && calculateBalance(rootNode.rightChild) > 0){ // RL disbalance case
            rootNode.rightChild = rightRotation(rootNode.rightChild);
            return leftRotation(rootNode);
        }
        return rootNode;
    }

    public AVL_Node findSubtreeMin(AVL_Node rootNode){ // function to find the lowest data element in the subtree
        if (rootNode == null || rootNode.leftChild == null){
            return rootNode;
        }
        return findSubtreeMin(rootNode.leftChild);
    }

    public AVL_Node insertNodeAVL(AVL_Node rootNode, String newData){
        if (rootNode == null){              //new node will be added as the left/right child (or root if empty tree) and recursion depth ends when we reach this condition
            return new AVL_Node(newData);
        } else if (newData.compareTo(rootNode.data) < 0){
            rootNode.leftChild = insertNodeAVL(rootNode.leftChild, newData);
        } else {
            rootNode.rightChild = insertNodeAVL(rootNode.rightChild, newData);
        }
        rootNode.height = 1 + max(getHeight(rootNode.leftChild),getHeight(rootNode.rightChild)); //updating height of each node when backtracking

        int rootNodeBalance = calculateBalance(rootNode);

        if (rootNodeBalance > 1 && newData.compareTo(rootNode.leftChild.data) < 0){ // LL condition
            return rightRotation(rootNode);
        }
        if (rootNodeBalance > 1 && newData.compareTo(rootNode.leftChild.data) > 0) { // LR condition
            rootNode.leftChild = leftRotation(rootNode.leftChild);
            return rightRotation(rootNode);
        }
        if (rootNodeBalance < -1 && newData.compareTo(rootNode.rightChild.data) > 0){ // RR condition
            return leftRotation(rootNode);
        }
        if (rootNodeBalance < -1 && newData.compareTo(rootNode.rightChild.data) < 0){ // RL condition
            rootNode.rightChild = rightRotation(rootNode.rightChild);
            return leftRotation(rootNode);
        }
        return rootNode;
    }

    public void deleteEntireAVLTree(AVL_Node rootNode){      //delete entire tree function
        rootNode.data = null;
        rootNode.leftChild = null;
        rootNode.rightChild = null;
    }

    public int getHeight(AVL_Node rootNode){         //function that gets the height of a node
        if (rootNode == null){
            return 0;
        }
        return rootNode.height;
    }

    public int calculateBalance(AVL_Node rootNode){      //function to calculate the balance of node as height of left child - height of right child
        if (rootNode == null){
            return 0;
        }
        return getHeight(rootNode.leftChild) - getHeight(rootNode.rightChild);
    }

    public AVL_Node rightRotation(AVL_Node unbalancedNode){     //right rotation function
        AVL_Node newRoot = unbalancedNode.leftChild;            //left child of unbalanced node will become root node of subtree
        unbalancedNode.leftChild = unbalancedNode.leftChild.rightChild; //new left child of unbalanced node is the left childs right child
        newRoot.rightChild = unbalancedNode;    //and the unbalanced node becomes the new roots (prev. left child) right child

        unbalancedNode.height = 1 + max(getHeight(unbalancedNode.leftChild), getHeight(unbalancedNode.rightChild)); //update the height of unb. node
        newRoot.height = 1 + max(getHeight(newRoot.leftChild), getHeight(newRoot.rightChild)); //update the height of new root

        return newRoot;
    }

    public AVL_Node leftRotation(AVL_Node unbalancedNode){      //left rotation function, opposite algorithm as right
        AVL_Node newRoot = unbalancedNode.rightChild;
        unbalancedNode.rightChild = unbalancedNode.rightChild.leftChild;
        newRoot.leftChild = unbalancedNode;

        unbalancedNode.height = 1 + max(getHeight(unbalancedNode.leftChild), getHeight(unbalancedNode.rightChild));
        newRoot.height = 1 + max(getHeight(newRoot.leftChild), getHeight(newRoot.rightChild));

        return newRoot;
    }

    public void preOrderTraversal(AVL_Node rootNode){    //pre order traversal print function

        if (rootNode == null){
            return;
        }

        System.out.println(rootNode.data + " " + rootNode.height);
        preOrderTraversal(rootNode.leftChild);
        preOrderTraversal(rootNode.rightChild);
    }

    public void main(String[] args) throws IOException {
        System.out.println("Welcome to the AVL Tree implementation!");
        AVL_Tree AVLTree = new AVL_Tree();
        AVLTree.rootNode = insertNodeAVL(AVLTree.rootNode,"One");
        AVLTree.rootNode = insertNodeAVL(AVLTree.rootNode,"Two");

        AVLTree.searchNodeAVL(AVLTree.rootNode,"One");
        preOrderTraversal(AVLTree.rootNode);

    }
}

