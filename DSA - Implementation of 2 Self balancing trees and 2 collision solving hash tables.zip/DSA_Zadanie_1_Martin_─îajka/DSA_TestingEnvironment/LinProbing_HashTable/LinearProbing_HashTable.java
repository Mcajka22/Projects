package LinProbing_HashTable;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class LinearProbing_HashTable {
    private static final double resizeFactor = .70;
    public int numOfElements = 0;
    public int currCapacity;
    public LinearProbing_Node[] hashTable;

    public LinearProbing_HashTable(){
        this.currCapacity = 50;
        this.hashTable = new LinearProbing_Node[currCapacity];
    }

    public void deleteLinearProbing_HashTable(String targetData){

        int hashResult = calcHashValue(targetData);
        this.numOfElements--;

        if (this.currCapacity > 50 && (float)this.numOfElements/(float)this.currCapacity < 1-this.resizeFactor){      //in case the table is 70 full we resize and rehash
            this.hashTable = resizeNegative(this.hashTable);
            hashResult = calcHashValue(targetData);
        }

        while (this.hashTable[hashResult] != null){     //while we do not get an empty index

            if (this.hashTable[hashResult].data.equals(targetData)) {       //found the node and deleted it
                this.hashTable[hashResult].isDeleted = true;            //set deleted to true
                return;
            }
            hashResult++;
            if (hashResult == this.currCapacity){      //if we reach the end of table, continue search from the beginning
                hashResult = 0;
            }
        }                                       //else out of loop, node does not exist
        this.numOfElements++;
        System.out.println("Data does not exist in the table! " + targetData);

    }

    public LinearProbing_Node[] resizeNegative(LinearProbing_Node[] oldHashTable){
        this.currCapacity /= 2;      //the new table capacity doubles when resize condition is met
        System.out.println("Resizing negatively, new capacity is " + this.currCapacity + " elements.");
        LinearProbing_Node[] newHashTable = new LinearProbing_Node[this.currCapacity];

        for (int i=0; i<(this.currCapacity*2); i++){            //re-maping the old hash table to the new one
            if (oldHashTable[i] != null){
                if (oldHashTable[i].isDeleted == true){         //during resizing we delete all nodes that were supposed to be deleted and still exist in the table - lazy delete approach
                    oldHashTable[i] = null;
                    continue;
                }

                oldHashTable[i].hashValue = calcHashValue(oldHashTable[i].data);     //we update hash of each node for new table
                int searchIndex = oldHashTable[i].hashValue;

                while (newHashTable[searchIndex] != null){     //and search for the first empty index from hash result index
                    searchIndex++;
                    if (searchIndex == this.currCapacity){      //if we reach the end of table we search for first null from the beginning
                        searchIndex = 0;
                    }
                }
                newHashTable[searchIndex] = oldHashTable[i];     //node is copied from old table to new

                oldHashTable[i] = null;         //remove every copied element of the old table
            }
        }
        return newHashTable;
    }

    public LinearProbing_Node searchLinearProbing_HashTable(String targetData){
        int hashResult = calcHashValue(targetData);
        int searchIndex = hashResult;

        while (this.hashTable[searchIndex] != null){     //while we do not get an empty index

            if (this.hashTable[searchIndex].data.equals(targetData) && this.hashTable[searchIndex].isDeleted == false){       //found the node, and it was not supposed to be deleted
                return this.hashTable[searchIndex];
            }

            searchIndex++;
            if (searchIndex == this.currCapacity){      //if we reach the end of table, continue search from the beginning
                searchIndex = 0;
            }
        }                                       //else out of loop, node does not exist
        System.out.println("Data does not exist in the table! " + targetData);
        return null;
    }

    public void insertLinearProbing_HashTable(String newData){

        LinearProbing_Node newNode = new LinearProbing_Node(newData);
        int searchIndex = calcHashValue(newData);
        newNode.hashValue = searchIndex;

        this.numOfElements++;

        if ((float)this.numOfElements/(float)this.currCapacity > this.resizeFactor){      //in case the table is 70 full we resize and rehash
            this.hashTable = resizePositive(this.hashTable);
        }

        while (this.hashTable[searchIndex] != null){     //while we do not get an empty index

            if (this.hashTable[searchIndex].isDeleted == true){     //if the node at index is deleted via the lazy delete approach
                this.hashTable[searchIndex] = newNode;
                return;
            }
            searchIndex++;
            if (searchIndex == this.currCapacity){      //if we reach the end of table, continue search from the beginning
                searchIndex = 0;
            }

        } //found null index -> insert
        this.hashTable[searchIndex] = newNode;
    }

    public LinearProbing_Node[] resizePositive(LinearProbing_Node[] oldHashTable){
        this.currCapacity *= 2;      //the new table capacity doubles when resize condition is met
        System.out.println("Resizing positively, new capacity is " + this.currCapacity + " elements.");
        LinearProbing_Node[] newHashTable = new LinearProbing_Node[this.currCapacity];

        for (int i=0; i<(this.currCapacity/2); i++){            //re-maping the old hash table to the new one
            if (oldHashTable[i] != null){
                if (oldHashTable[i].isDeleted == true){         //during resizing we delete all nodes that were supposed to be deleted and still exist in the table - lazy delete approach
                    oldHashTable[i] = null;
                    continue;
                }

                oldHashTable[i].hashValue = calcHashValue(oldHashTable[i].data);     //we update hash of each node for new table
                int searchIndex = oldHashTable[i].hashValue;

                while (newHashTable[searchIndex] != null){     //and search for the first empty index from hash result index
                    searchIndex++;
                    if (searchIndex == this.currCapacity){      //if we reach the end of table we search for first null from the beginning
                        searchIndex = 0;
                    }
                }
                newHashTable[searchIndex] = oldHashTable[i];     //node is copied from old table to new

                oldHashTable[i] = null;         //remove every copied element of the old table
            }
        }
        return newHashTable;
    }

    public int calcHashValue(String data){      //calculates the hash value for given data string as the sum of characters of string multiplied by seven each iteration (prime number)
        int hashResult = 0;

        for (int i=0; i<data.length(); i++){
            hashResult = hashResult * 7 + data.charAt(i);
        }
        return Math.abs(hashResult) % this.currCapacity;
    }

    public void printHashTable(){       //prints the hash table and chained nodes to given indexes
        for (int i=0; i < this.currCapacity; i++){
            if (this.hashTable[i] == null || this.hashTable[i].isDeleted == true){
                System.out.println(i + " ---");
            } else{
                System.out.println(i + " " + this.hashTable[i].data);
            }
        }
    }

    public static void main(String[] args) throws FileNotFoundException {

        File testFile = new File("testData.txt");
        Scanner scannerInsert = new Scanner(testFile);
        Scanner scannerDelete = new Scanner(testFile);
        Scanner scannerSearch = new Scanner(testFile);


        LinearProbing_HashTable HashTable = new LinearProbing_HashTable();

        for (int i = 0; i < 50; i++){
            String newDataString = scannerInsert.nextLine();
            HashTable.insertLinearProbing_HashTable(newDataString);
        }

        for (int j = 0; j < 50; j++){
            String newDataString = scannerSearch.nextLine();
            System.out.println(HashTable.searchLinearProbing_HashTable(newDataString));
        }

        for (int j = 0; j < 30; j++){
            String newDataString = scannerDelete.nextLine();
            HashTable.deleteLinearProbing_HashTable(newDataString);
        }
        HashTable.searchLinearProbing_HashTable("One");
        HashTable.deleteLinearProbing_HashTable("One");

        HashTable.printHashTable();
        scannerInsert.close();
        scannerSearch.close();
        scannerDelete.close();

    }
}
