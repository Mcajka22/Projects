package LinProbing_HashTable;

public class LinearProbing_Node {
    boolean isDeleted = false;
    int hashValue;
    String data;

    public LinearProbing_Node(String newData){
        this.data = newData;
    }
}
